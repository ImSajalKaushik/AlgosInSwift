import UIKit

var str = "Hello, {strong}playground"
///========================================================================================================
///Dynamic Programming
///========================================================================================================

var a  = ["email": "lilith@getnada.com", "version": "5", "MMNNumber": "BASAL123"]


var sum = 0
var i = 0
while i < 100 {
    sum = sum+i
    sum = i+sum
    i += 1
}
print(sum)
MemoryLayout<Bool>.size
///========================================================================================================
///Backtracking
///========================================================================================================



class Day61 {
    func subsetHelper(_ A: [Int]) -> [[Int]] {
        var res = [[Int]]()
        let B = A.sorted()
        var currentSet = [Int]()
        subsets2(B, index: 0, currentSet: &currentSet, res: &res)
        //res.remove(at: 0)
//        res.sort {
//            let first = $0
//            let second = $1
//            for index in 0 ..< min(first.count, second.count) {
//                if first[index] != second[index] {
//                    return first[index] < second[index]
//                }
//            }
//            return $0.count < $1.count
//        }
        print(res)
        return res
    }
    
    
    func subsets(_ A: [Int], index: Int, currentSet: inout [Int], res: inout [[Int]]) {
        if index == A.count {
            if !res.contains(where: {$0 == currentSet}) {
                res.append(currentSet)
            }
            return
        }
        var op1 = currentSet
        var op2 = currentSet
        op2.append(A[index])
        subsets(A, index: index+1, currentSet: &op1, res: &res)
        subsets(A, index: index+1, currentSet: &op2, res: &res)
    }
    
    
    
    func subsets2(_ A: [Int], index: Int, currentSet: inout [Int], res: inout [[Int]]) {
        res.append(currentSet)
        for i in index..<A.count {
            if i > index && A[i] == A[i-1] {
                continue
            }
            currentSet.append(A[i])
            subsets2(A, index: i+1, currentSet: &currentSet, res: &res)
            currentSet.removeLast()
        }
        
    }
    
    func combinationHelper(_ A: inout Int, _ B: inout Int) -> [[Int]] {
        var res = [[Int]]()
        if B == 0 {
              return []
        }
        if A < B {
            return res
        }
       
        var currentSet = [Int]()
        combinationK(0, A, B, &currentSet, &res)
        return res
    }
    
    func combinationK(_ start: Int, _ A: Int, _ B: Int, _ currentSet: inout [Int], _ res: inout [[Int]]) {
        if B == 0 {
            res.append(currentSet)
            return
        }
        
        for i in start..<A {
            currentSet.append(i + 1)
            combinationK(i + 1, A, B - 1, &currentSet, &res)
            currentSet.removeLast()
        }
    }
    
    func combinationSumHelper(_ A: inout [Int], _ B: inout Int) -> [[Int]]{
        if A.count < 1 {
            return []
        }
        A = A.sorted()
        var res = [[Int]]()
        var currentSet = [Int]()
        combinationSum(0, A, B, &currentSet, &res)
        return res
    }
    /// with repetitiopn , NOT CORRECT
    func combinationSum(_ index: Int, _ A: [Int], _ sum: Int, _ currentSet: inout [Int], _ res: inout [[Int]]) {
        if sum == 0 {
            if !res.contains(where: {$0 == currentSet}) {
                res.append(currentSet)
            }
            return
        }
        for i in index ..< A.count {
            if A[index] > sum {
                return
            }
            if A[index] <= sum {
                currentSet.append(A[index])
            }
            combinationSum(index, A, sum-A[i], &currentSet, &res)
            currentSet.removeLast()
        }
    }
    
    func combinationSumWithoutRep(_ A: inout [Int], _ B: Int) -> [[Int]] {
        if A.count < 1 {
            return []
        }
       A = A.sorted()
        print(A)
        var res = [[Int]]()
        var currentSet = [Int]()
        combinationSumWithoutRep(0, A, B, &currentSet, &res)
        print(res)
        return res
    }
    
    
    func combinationSumWithoutRep(_ currentIndex: Int, _ A: [Int], _ sum: Int, _ currentSet: inout [Int], _ res: inout [[Int]]) {
        if sum < 0 {
            return
        }
        if sum == 0 {
            if !res.contains(where: {$0 == currentSet}) {
                print(currentSet)
                res.append(currentSet)
            }
            return
        }

        for index in currentIndex..<A.count {
            currentSet.append(A[index])
            combinationSumWithoutRep(index+1, A, sum-A[index], &currentSet, &res)
            currentSet.removeLast()
        }
    }

    func letterPhoneHelper(_ digitSequence: String) -> [String] {
        if digitSequence.count < 1 {
            return [""]
        }
        let digitMap: [Character: [String]] = ["0": ["0"],
                                               "1" : ["1"],
                                               "2": ["a","b","c"],
                                               "3": ["d","e","f"],
                                               "4": ["g","h","i"],
                                               "5": ["j","k","l"],
                                               "6": ["m","n","o"],
                                               "7": ["p","q","r", "s"],
                                               "8": ["t","u","v"],
                                               "9": ["w","x","y","z"]]
        var res = [String]()
        var currentSet = ""
        let input = Array(digitSequence)
        letterPhone(input, 0, digitMap, &currentSet, &res)
        print(res)
        return res
    }
    
    func letterPhone(_ input: [Character], _ currentIndex: Int, _ map: [Character: [String]], _ currentSet: inout String, _ res: inout [String]) {
        if currentIndex == input.count {
            res.append(currentSet)
            return
        }
        guard let mapValues = map[input[currentIndex]] else { return }
        for i in 0..<mapValues.count {
            currentSet.append(mapValues[i])
            letterPhone(input, currentIndex+1, map, &currentSet, &res)
            currentSet.removeLast()
        }
    }
    
    
    func palindromePartitioningHelper(_ A: String) -> [[String]] {
        if A.count < 1 {
            return []
        }
        var res = [[String]]()
        var currentSet = [String]()
        palindromePartitioning(A, &currentSet, &res)
        print(res)
        return res
    }
    
    func palindromePartitioning(_ A: String, _ currentSet : inout [String], _ res: inout [[String]]) {
        if A.count == 0 {
            res.append(currentSet)
        }
        let original = A
        for index in 0..<A.count {
            let indexInString = original.index(original.startIndex, offsetBy: index+1)
            let leftPart = original.substring(to: indexInString)
            let rightPart = original.substring(from: indexInString)
            if isPalindrome(leftPart) {
                currentSet.append(leftPart)
                palindromePartitioning(rightPart, &currentSet, &res)
                currentSet.removeLast()
            }
        }
    }
    
    func isPalindrome(_ partition: String) -> Bool {
        let A = Array(partition)
        var start = 0
        var end = A.count-1
        while start <= end {
            if A[start] != A[end] {
                return false
            }
            start += 1
            end -= 1
        }
        return true
    }
    
    func generateParenthesesHelper(_ A: Int) -> [String] {
        let currentSet = ""
        var res = [String]()
        generateParentheses(currentSet, &res, open: A, close: A)
        print(res)
        return res
    }
    
    
    func generateParentheses(_ currentSet: String, _ res: inout [String], open: Int, close: Int) {
        if open == 0 && close == 0 {
            res.append(currentSet)
            return
        }
        if open != 0 {
            generateParentheses(currentSet + "(", &res, open: open-1, close: close)
        }
        if close > open {
            generateParentheses(currentSet + ")", &res, open: open, close: close-1)
        }
    }
    
    func generatePermutationsHelper(_ A: [Int]) -> [[Int]] {
        var currentSet = [Int]()
        var res = [[Int]]()
        var visited = Array(repeating: false, count: A.count)
        generatePermutations(A, &currentSet, &res, &visited)
        print(res)
        return res
    }
    
    
    func generatePermutations(_ input: [Int], _ currentSet: inout [Int], _ res: inout [[Int]], _ visited: inout [Bool]) {
        if currentSet.count == input.count {
            res.append(currentSet)
            return
        }
        for index in 0..<input.count {
            if visited[index] == true {continue}
            currentSet.append(input[index])
            visited[index] = true
            generatePermutations(input, &currentSet, &res, &visited)
            visited[index] = false
            currentSet.removeLast()
        }
    }
    
    
    func nQueenHelper(_ A: Int) {
        var board = Array(repeating: Array(repeating: 0, count: A), count: A)
        let row = 0
        if nQueen(&board, row) {
            print(board)
            
        }
    }
    func isSafeForQueen(_ board: [[Int]], _ rowInQuestion: Int, _ colInQuestion: Int) -> Bool {
        var row = rowInQuestion
        var col = colInQuestion
        while row >= 0 && col >= 0 {
            if board[row][col] == 1 {
                return false
            }
            row -= 1
            col -= 1
        }
        
        row = rowInQuestion
        col = colInQuestion
        while row >= 0 && col < board.count {
            if board[row][col] == 1 {
                return false
            }
            row -= 1
            col += 1
        }
        
        row = rowInQuestion
        col = colInQuestion
        while row >= 0 && col >= 0 {
            if board[row][col] == 1 {
                return false
            }
            row -= 1
        }
        return true
    }
    
    func nQueen(_ board: inout [[Int]], _ row: Int) -> Bool {
        if row == board.count {
            return true
        }
        for col in 0..<board[0].count {
            if isSafeForQueen(board, row, col) {
                board[row][col] = 1
                if nQueen(&board, row+1) {
                    return true
                }
                board[row][col] = 0
            }
        }
        return false
    }
    
    
    
    func sudokuHelper(_ A: [[Int]]) {
        var board = A
        sudoku(&board, 0,0)
        print(board)
    }
    
    func isSafePlacement(_ board: [[Int]], _ row: Int, _ col: Int, _ value: Int) -> Bool {
        if board[row][col] != 0 {
            return false
        }
        //
        var rowToCheck = row-1
        while rowToCheck >= 0 {
            if board[rowToCheck][col] == value {
                return false
            }
            rowToCheck -= 1
        }
        
        
        var colToCheck = col-1
        while colToCheck >= 0 {
            if board[row][colToCheck] == value {
                return false
            }
            colToCheck -= 1
        }
        
        //block
        let startRow = row - row%3
        let startCol =  col - col%3
        for r in 0..<3 {
            for c in 0..<3 {
                if board[r+startRow][c+startCol] == value {
                    return false
                }
            }
        }
        return true
    }
    
    func sudoku(_ board: inout [[Int]], _ row: Int, _ col: Int) -> Bool {
        print("row: \(row) col: \(col)")
        if row == board.count && col == board.count {
            return true
        }
        if row >= board.count {
            return false
        }
        for index in 0..<board.count {
            for value in 1...9 {
                if isSafePlacement(board, row, index, value) {
                    board[row][index] = value
                    if sudoku(&board, row+1, index) {
                        return true
                    }
                    board[row][index] = 0
                }
            }
        }
        return false
    }
}

let d61 = Day61()
var d61A = [ 1,2,2]
var Aa = 8
var bb = 6
var board = [ [ 3, 0, 6, 5, 0, 8, 4, 0, 0 ],
              [ 5, 2, 0, 0, 0, 0, 0, 0, 0 ],
              [ 0, 8, 7, 0, 0, 0, 0, 3, 1 ],
              [ 0, 0, 3, 0, 1, 0, 0, 8, 0 ],
              [ 9, 0, 0, 8, 6, 3, 0, 0, 5 ],
              [ 0, 5, 0, 0, 9, 0, 6, 0, 0 ],
              [ 1, 3, 0, 0, 0, 0, 2, 5, 0 ],
              [ 0, 0, 0, 0, 0, 0, 0, 7, 4 ],
              [ 0, 0, 5, 2, 0, 6, 3, 0, 0 ] ]
d61.sudokuHelper(board)

























///========================================================================================================
///Dynamic Programming
///========================================================================================================


class Day60 {
    
    func maximumSumSubMatrix(_ A: [[Int]]) -> Int {
        var maxSorFar = Int.min
        for row1 in 0..<A.count {
            var cumulativeColumn = A[row1]
            for row2 in row1..<A.count {
                if row1 != row2 {
                    for i in 0..<A[0].count {
                        cumulativeColumn[i] = cumulativeColumn[i] + A[row2][i]
                    }
                }
                let maxValue = kadane(cumulativeColumn)
                maxSorFar = max(maxValue, maxSorFar)
            }
        }
        return maxSorFar
    }
    
    func kadane(_ A: [Int]) -> Int {
        var maxSofar = A[0]
        var currentMax = A[0]
        for i in 1..<A.count {
            currentMax = max(A[i], currentMax+A[i])
            maxSofar = max(currentMax, maxSofar)
            
        }
        return maxSofar
    }
    
    
    func minSumPath(_ A: [[Int]], _ row: Int, _ col: Int) -> Int {
        if row < 0 || col < 0 {
            return Int.max
        }
        if row == 0 && col == 0 {
            return A[0][0]
        }
        if dp[row][col] != -1 {
            return dp[row][col]
        }
        let ans = A[row][col] + min (minSumPath(A, row-1, col), minSumPath(A, row, col-1))
        dp[row][col] = ans
        return ans
    }
    
    var dp = Array(repeating: Array(repeating: -1, count: 4), count: 8)
    
    
    func knightEnergy(_ A: [[Int]], _ row: Int, _ col: Int) -> Int {
        if row > A.count-1 || col > A[0].count-1 {
            return Int.max
        }
        if dp[row][col] != -1 {
            return dp[row][col]
        }
        // when queen is found return 1 when +ve else return abs(value)
        if row+1 == A.count && col+1 == A[0].count {
            let value = A[row][col]
            if value >= 0 {
                return 1
            } else {
                return -1*(value-1)
            }
        }
        
        let temp =  min(knightEnergy(A, row+1, col), knightEnergy(A, row, col+1)) - A[row][col]
        print("val: \(A[row][col]) tem = \(temp)")
        dp[row][col] = temp <= 0 ? 1 : temp
        return dp[row][col]
    }
    
    
    func minPathInTriangle(_ A: [[Int]], _ row: Int, _ col: Int) -> Int {
        if row >= A.count || col >= A[0].count {
            return Int.max
        }
        if dp[row][col] != -1 {
            return dp[row][col]
        }
        if row+1 == A.count {
            dp[row][col] = A[row][col]
            return A[row][col]
        }
        let ans = A[row][col] + min(minPathInTriangle(A, row+1, col) , minPathInTriangle(A, row+1, col+1))
        dp[row][col] = ans
        return dp[row][col]
    }
    
    func uniquePathsInGrid(_ A: [[Int]], _ row: Int, _ col: Int) -> Int {
        if row < 0 || col < 0 || A[row][col] == 1 {
            return 0
        }
        //        print("row: \(row) col: \(col)")
        if dp[row][col] != -1 {
            return dp[row][col]
        }
        if row == 0 && col == 0 {
            return 1
        }
        let ans =  uniquePathsInGrid(A, row-1, col) + uniquePathsInGrid(A, row, col-1)
        dp[row][col] = ans
        return dp[row][col]
    }
    
    //    func roadCutting(_ A: [Int], _ size: Int, _ res: inout [Int], _ index: Int ) -> Int {
    //        if size == 0 || index == A.count-1 {
    //            return 0
    //        }
    //         print("size: \(size) index: \(index)")
    //        var ans = 0
    //        if dp[size][index] != -1 {
    //            return dp[size][index]
    //        }
    //        if size > A[index] {
    //            var op = res
    //            op.append(A[index])
    //            ans = min(A[index] + roadCutting(A, size-A[index], &op, index) , roadCutting(A, size, &res, index+1))
    //        } else {
    //            ans = roadCutting(A, size, &res, index+1)
    //        }
    //        dp[size][index] = ans
    //        return dp[size][index]
    //    }
    
    func coinSum(_ coins: [Int], _ sum: Int ) -> Int {
        if coins.count == 0 {
            return 0
        }
        dp = Array(repeating: Array(repeating: -1, count: sum+1), count: coins.count+1)
        var t = Array(repeating: 0, count: sum+1)
        for i in 0...coins.count {
            for j in 0...sum {
                if i == 0 || j == 0 {
                    if j == 0 {
                        t[j] = 1
                    } else {
                        t[j] = 0
                    }
                    
                } else {
                    if j >= coins[i-1] {
                        t[j] = t[j-coins[i-1]]%1000007 + t[j]%1000007
                    } else {
                        t[j] = t[j]%1000007
                    }
                }
            }
            //print(t)
        }
        return t[sum] % 1000007
    }
    
    ///Best Time to Buy and Sell Stocks I
    func bestTime(_ stockPrices: [Int]) -> Int {
        if stockPrices.count < 2 {
            return 0
        }
        var minValue = stockPrices[0]
        var maxProfit = 0
        for i in 1..<stockPrices.count {
            if stockPrices[i] -  minValue > maxProfit {
                maxProfit =  stockPrices[i] -  minValue
            }
            if stockPrices[i] < minValue {
                minValue = stockPrices[i]
            }
        }
        return maxProfit
    }
    ///Best Time to Buy and Sell Stocks II
    
    func sellStocksNTime(_ prices: [Int]) -> Int {
        var profit = 0
        for i in 1..<prices.count {
            if prices[i] > prices[i-1] {
                profit +=  prices[i] - prices[i-1]
            }
        }
        return profit
    }
    
    
    func maximumProductSubarray(_ A: [Int]) -> Int {
        var prevMax = A[0]
        var preMin = A[0]
        var maxSofar = A[0]
        for i in 1..<A.count {
            let currentMax = max(prevMax*A[i], max(preMin*A[i], A[i]))
            let currentMin = min(prevMax*A[i], min(preMin*A[i], A[i]))
            maxSofar = max(currentMax, maxSofar)
            prevMax = currentMax
            preMin = currentMin
        }
        return maxSofar
    }
    
    /// Arrange II
    
    //    func horsesInStable(_ A: [Character], _ start: Int, _ partitions: Int) -> Int {
    //        if start == A.count && partitions==0 {
    //            return Int.max
    //        }
    //        if partitions <= 0 {
    //            return -1
    //        }
    //        if t[start][partitions] != -1 {
    //            return t[start][partitions]
    //        }
    //        var ans = Int.max
    //        var white = 0
    //        var black = 0
    //        for k in start..<A.count {
    //            if A[k] == "W" { white+=1}
    //            if A[k] == "B" {black+=1}
    //            let temp = horsesInStable(A, start+1, k-1)
    //            if temp != -1 && temp != Int.max {
    //                ans = min(ans, temp + white*black)
    //            }
    //
    //
    //        }
    //        t[start][partitions] = ans
    //        return t[start][partitions]
    //    }
    
    
    /// Tushar's Birthday Party
    var capacityDP = [[Int]]()
    func birthdayParty(_ A: [Int], _ DishCapacity: [Int] , _ Cost: [Int]) -> Int {
        var maxInArray = Int.min
        for item in A {
            maxInArray = max(maxInArray, item)
        }
        // last line is relevant to us
        capacityDP = Array(repeating: Array(repeating: -1, count: maxInArray+1), count: DishCapacity.count+1)
        unBoundedKnock(DishCapacity, maxInArray, DishCapacity.count,Cost)
        var finalCost = 0
        for item in A {
            finalCost += capacityDP[A.count][item]
        }
        return finalCost
    }
    
    func unBoundedKnock(_ A: [Int], _ capacity: Int, _ size: Int, _ cost: [Int]) -> Int {
        if capacity == 0 && size == 0 {
            capacityDP[size][capacity] = Int.max/2
            return capacityDP[size][capacity]
        }
        if capacity == 0 {
            capacityDP[size][capacity] = 0
            return capacityDP[size][capacity]
        }
        if size <= 0 || capacity < 0{
            capacityDP[size][capacity] = Int.max/2
            return capacityDP[size][capacity]
        }
        if capacityDP[size][capacity] != -1 {
            return capacityDP[size][capacity]
        }
        var ans = 0
        if capacity >= A[size-1] {
            ans = min(cost[size-1] + unBoundedKnock(A, capacity-A[size-1], size, cost), unBoundedKnock(A, capacity, size-1, cost))
        } else {
            ans = unBoundedKnock(A, capacity, size-1, cost)
        }
        capacityDP[size][capacity] = ans
        
        return capacityDP[size][capacity]
    }
    
    func unBoundedKnockTopDown(_ A: [Int], _ capacity: Int, _ cost: [Int]) {
        
        for i in 0...A.count {
            for j in 0...capacity {
                if i == 0 || j == 0 {
                    if i == 0 {
                        capacityDP[i][j] = Int.max/2
                    } else {
                        capacityDP[i][j] = 0
                    }
                } else {
                    if A[i-1] <= j {
                        capacityDP[i][j] = min(cost[i-1] + capacityDP[i][j-A[i-1]], capacityDP[i-1][j])
                    } else {
                        capacityDP[i][j] = capacityDP[i-1][j]
                    }
                }
                
            }
            
        }
    }
    
    //var t = [[Int]]()
    var t = [Int]()
    func minSubsetSumDifference(_ A: [Int]) -> Int {
        var sum = 0
        for item in A {
            sum += item
        }
        let maxSum = sum
        sum = sum/2
        subsetSum(A, sum)
        let lastRow = t
        var minValue = Int.max
        for i in 0..<lastRow.count {
            let value = lastRow[i] == 1 ? abs(maxSum - 2*i) : Int.max
            if lastRow[i] == 1 {print("sum \(sum) i : \(i)")}
            minValue = min(minValue, value)
        }
        return minValue
    }
    
    func subsetSum(_ A: [Int], _ sum: Int) {
        //t = Array(repeating: Array(repeating: -1, count: sum+1), count: A.count+1)
        t = Array(repeating: -1, count: sum+1)
        for row in 0...A.count {
            for col in 0...sum {
                if row == 0 || col == 0 {
                    if row == 0 {
                        t[col] = 0
                    } else {
                        t[col] = 1
                    }
                } else {
                    if col >= A[row-1] {
                        t[col] = max(t[col-A[row-1]], t[col])
                    } else {
                        t[col] = t[col]
                    }
                    
                }
            }
        }
    }
    
    func maxSumWithoutAdjacent(_ A: [Int]) -> Int { /// use max(A[i] + dp[i-2] + dp[i-1])  bbase case till dp[2]
        if A.count < 1 {
            return 0
        }
        var including = A[0]
        var excluding = 0
        for i in 1..<A.count {
            let temp = including
            including = excluding + A[i]
            excluding = max(excluding, temp)
        }
        return max(including, excluding)
    }
    
//    func maxSumPathInTree(_ A: TreeNode?, _ res: inout Int) -> Int {
//        if A == nil {
//            return 0
//        }
//        let left = maxSumPathInTree(A?.left, &res)
//        let right = maxSumPathInTree(A?.right, &res)
//        let temp = max( max(left, right) + A!.val , A!.val)
//        let ans = max(temp, A!.val+left+right)
//        res = max(res, ans)
//        return temp
//    }
    
    var catalan = [Int]()
    func catalanNumber(_ A: Int) {
        catalan = Array(repeating: -1, count: A+1)
        catalan[0] = 1
        catalan[1] = 1
        if A < 2 {
            return
        }
        for i in 2...A {
            catalan[i] = 0
            for j in 0..<i {
                catalan[i] += catalan[j]*catalan[i-j-1]
            }
        }
    }

    var pdp = Array(repeating: Array(repeating: -1, count: 5), count: 5)
    func palindromePartitioning(_ A: [Character], _ start: Int , _ end: Int) -> Int {
        if start >= end {
            return 0
        }
        if pdp[start][end] != -1 {
            return 0
        }
       // print("start \(start) end \(end)")
        
        if isPalindrome(A, start, end) {
            pdp[start][end] = 0
            return pdp[start][end]
        }
        var ans = Int.max
        for k in start..<end {
            ///print("k: \(k)")
            let left =  palindromePartitioning(A, start, k)
            let right = palindromePartitioning(A, k+1, end)
            let temp = left + right + 1
            ans = min(temp, ans)
        }
        pdp[start][end] = ans
        return pdp[start][end]
    }
    
    func isPalindrome(_ A: [Character], _ i: Int, _ j: Int) -> Bool {
        var start = i
        var end = j
        while start <= end {
            if A[start] != A[end] {
                return false
            }
            start += 1
            end -= 1
        }
        return true
    }
}




let d60 = Day60()
let str2 = "abcd"
let A =  "dVGAaVO25EmT6W3zSTEA0k12i64Kkmmli09Kb4fArlF4Gc2PknrlkevhROxUg"
print(str2.count)

let d60A = Array(str2)
let d60B = [1, 3]
let d60C = [5,3]
var es = [Int]()
let d60ans = d60.palindromePartitioning(d60A,0,d60A.count-1)
for item in pdp {
    print(item)
}





class Day59 {
    func longestAP(_ A: [Int]) -> Int {
        if A.count < 3 {
            return 2
        }
        var A = A.sorted()
        print(A)
        var dp = Array(repeating: 2, count: A.count)
        var ans = 2
        for j in stride(from: A.count-1, through: 0, by: -1) {
            var i = j-1
            var k = j+1
            while k < A.count && i >= 0 {
                if  A[i] + A[k] == 2*A[j] {
                    dp[j] = max(dp[k]+1, dp[j])
                    ans = max(ans, dp[j])
                    i-=1
                    k+=1
                } else if A[i] + A[k] < 2*A[j] {
                    print("i: \(i) j: \(j) k: \(k)")
                    k+=1
                } else {
                    print("i: \(i) j: \(j) k: \(k)")
                    i-=1
                }
            }
        }
        return ans
    }
    
    
//    func shortestSuperString(_ A: [Character], _ B: [Character]) -> Int {
//         t = Array(repeating: Array(repeating: -1, count: B.count+1), count: A.count+1)
//        for i in 0...A.count {
//            for j in 0...B.count {
//                if i == 0 || j == 0 {
//                    t[i][j] = 0
//                } else if A[i-1] == B[j-1] {
//                    t[i][j] = 1 + t[i-1][j-1]
//                } else {
//                     t[i][j] = max(t[i-1][j],t[i][j-1])
//                }
//            }
//        }
//        return t[A.count][B.count]
//    }
    
    
    func kthManhattanDistance(_ B: [[Int]], _ A: Int) -> [[Int]] {
        var manhattanDistance  = B
        for _ in 0..<A {
            for i in 0..<B.count {
                for j in 0..<B[0].count {
                    let current = B[i][j]
                    let top = i-1 >= 0 ? manhattanDistance[i-1][j] : B[i][j]
                    let down = i+1 < B.count ? manhattanDistance[i+1][j] : B[i][j]
                    let left = j-1 >= 0 ? manhattanDistance[i][j-1] : B[i][j]
                    let right = j+1 < B[0].count ? manhattanDistance[i][j+1]: B[i][j]
                    let value = max(current, max(left, max(right, max(top, down))))
                    manhattanDistance[i][j] = value
                }
            }
        }
        return manhattanDistance
    }
    //var dp = [[Int]]()
    func maxProfitBBySellingStocksKTimes(_ A: [Int], _ B: Int) -> Int {
        dp = Array(repeating: Array(repeating: -1, count: A.count), count: B+1)
        for i in 0...B {
            for j in 0..<A.count {
                if i == 0 || j == 0 {
                    dp[i][j] = 0
                } else {
                    var maxSofar = 0
                    for m in 0..<j {
//                        print("i: \(i) j: \(j) m: \(m)")
                        maxSofar = max(maxSofar,
                                       A[j] - A[m] + dp[i-1][m]
                        )
                        dp[i][j] = max(dp[i][j-1], maxSofar)
                    }
                    
                }
            }
        }
        return dp[B][A.count-1]
    }
    
    func optimizedMaxProfitBBySellingStocksKTimes(_ A: [Int], _ B: Int) -> Int {
            dp = Array(repeating: Array(repeating: -1, count: A.count), count: B+1)
            for i in 0...B {
                var prevDiff = Int.min
                for j in 0..<A.count {
                    if i == 0 || j == 0 {
                        dp[i][j] = 0
                    } else {
                        prevDiff = max(prevDiff, dp[i-1][j-1] - A[j-1])
                        dp[i][j] = max(dp[i][j-1], A[j]+prevDiff)
                    }
                }
            }
            return dp[B][A.count-1]
        }
        
    var dp = Array(repeating: Array(repeating: -1, count: 6), count: 6)
    func optimalStrategyForGame(_ A: [Int], _ start: Int, _ end: Int) -> Int {
        if start > end {
            return 0
        }
        if start == end {
            return A[start]
        }
        if dp[start][end] != -1 {
            return dp[start][end]
        }
        let value = max(A[start] + min(optimalStrategyForGame(A, start+2, end), optimalStrategyForGame(A, start+1, end-1)),
                        A[end] + min(optimalStrategyForGame(A, start, end-2), optimalStrategyForGame(A, start+1, end-1)))
        dp[start][end] = value
        return dp[start][end]
    }
    
    var map = [String : Int]()
    
    func evaluateExpressionToTrue(_ A: [Character], _ start: Int, _ end: Int, _ isTrue : Bool) -> Int {
        if start > end {
            return 0
        }
        
        if start == end {
            if isTrue {
                return A[start] == "T" ? 1 : 0
            } else {
                return A[start] == "F" ? 1 : 0
            }
        }
        
        if map["\(start) + \(end) + \(isTrue)"] != nil {
            return map["\(start) + \(end) + \(isTrue)"]!
        }
        var ans = 0
        for mid in stride(from: start+1, to: end, by: 2)  {
            
            let lT = evaluateExpressionToTrue(A, start, mid-1, true)
            let rT = evaluateExpressionToTrue(A, mid+1, end, true)
            let lF = evaluateExpressionToTrue(A, start, mid-1, false)
            let rF = evaluateExpressionToTrue(A, mid+1, end, false)
            
            if A[mid] ==  Character("&") {
                if isTrue {
                    ans = ans + lT*rT
                } else {
                    ans = ans + lT*rF + lF*rT + lF*rF
                }
            } else if A[mid] == Character("|") {
                if isTrue {
                    ans = ans + lT*rT + lF*rT + lT*rF
                } else {
                    ans = ans + lF*rF
                }
            } else if A[mid] == Character("^") {
                if isTrue {
                    ans = ans + lF*rT + lT*rF
                } else {
                    ans = ans + lT*rT + lF*rF
                }
            }
        }
        map["\(start) + \(end) + \(isTrue)"] = ans%1003
        return map["\(start) + \(end) + \(isTrue)"]!
    }
}


let d59 = Day59()
var d59A = Array("T^T^T^F|F&F^F|T^F^T")
var k = 2
let ans = d59.evaluateExpressionToTrue(d59A, 0, d59A.count-1, true)
for item in d59.map {
    print(item)
}











class Day58 {
    // var t = [[Int]]()
    func longestIncreasingSubsequence(_ A: [Int]) -> [Int] {
        var lis = Array(repeating: 1, count: A.count)
        for i in 0..<A.count {
            for j in 0..<i {
                if A[i] > A[j] && lis[j] >= lis[i]{
                    lis[i] = lis[j]+1
                }
            }
        }
//        var best = 0
//        for item in lis {
//            best = max(best, item)
//        }
       return lis
    }

    
    func longestDecreasingSubsequence(_ A: [Int]) -> [Int] {
         var lds = Array(repeating: 1, count: A.count)
        for i in stride(from: A.count-1, through: 0, by: -1) {
            for j in i..<A.count  {
                 if A[i] > A[j] && lds[j] >= lds[i]{
                     lds[i] = lds[j]+1
                 }
             }
         }

        return lds
     }
    
    func longestBitonic(_ A: [Int]) -> Int {
        let lis = longestIncreasingSubsequence(A)
        let lds = longestDecreasingSubsequence(A)
        var ans = 0
        for i in 0..<A.count {
           let value  = lis[i] + lds[i] - 1
            ans =  max(ans, value)
        }
        return ans
    }
    
    
    func largestAreaOfRectangleWithPermutation(_ A: [[Int]]) -> Int {
        if A.isEmpty {
            return 0
        }
        var cumulativeMatrix = Array(repeating: Array(repeating: 0, count: A[0].count), count: A.count)
        /// Form column cumulative matrix
        for i in 0..<A.count {
            for j in 0..<A[0].count {
                if i == 0 {
                    cumulativeMatrix[i][j] = A[i][j]
                } else {
                   // print("i is \(i) & j is \(j) \(A[i-1][j])  \(A[i][j]))")
                    cumulativeMatrix[i][j] = A[i][j] == 0 ? 0 : cumulativeMatrix[i-1][j] + A[i][j]
                    
                }
            }
        }
        
        /// Sort the rows
        for i in 0..<A.count{
            cumulativeMatrix[i] = cumulativeMatrix[i].sorted()
        }
        //print(cumulativeMatrix)
        
        /// Max area per row
        var maxArea = 0
        for i in 0..<cumulativeMatrix.count {
            var width = 1
            for j in stride(from: cumulativeMatrix[0].count-1, to: 0, by: -1) {
                let area = width*cumulativeMatrix[i][j]
                width += 1
                maxArea = max(area, maxArea)
            }
        }
        return maxArea
    }
    
    
    func superUglyNumbers(_ A: Int, _ B: Int, _ C: Int, _ D: Int) -> [Int] {
        let arrSize = D+1
        var superUgly = Array(repeating: 1, count: arrSize)
        var firstIndex = 0
        var secondIndex = 0
        var thirdIndex = 0
        superUgly[0] = 1
        for i in 1..<arrSize {
            superUgly[i] = min(A*superUgly[firstIndex], min(B*superUgly[secondIndex], C*superUgly[thirdIndex]))
            if superUgly[i] == A*superUgly[firstIndex] {
                firstIndex += 1
            }
            if superUgly[i] == B*superUgly[secondIndex] {
                secondIndex += 1
            }
            if superUgly[i] == C*superUgly[thirdIndex] {
                thirdIndex += 1
            }
        }
        superUgly.remove(at: 0)
        print(superUgly)
        return superUgly
    }
    
    
    func decoding(_ A: String) -> Int {
        let subString = Array(A)
        let ans = countPossibleDecodings(subString)
        return ans
        
    }
    
//    func countPossibleDecodings(_ A: [Character], _ start: Int) -> Int {
//        if start == A.count-1 {
//            return 1
//        }
//        if start == A.count-2 {
//            if A[start] == "0"{
//                return 0
//            } else {
//                return 1
//            }
//        }
//        var ways = 0
//        let number : Int = Int(String(A[start]))! * 10 +  Int(String(A[start+1]))!
//        print(number)
//        if number > 9 && number < 27 {
//            ways = countPossibleDecodings(A, start+2)
//        }
//        ways += countPossibleDecodings(A, start+1)
//        return ways
//    }
    
    func countPossibleDecodings(_ A: [Character]) -> Int {
        var dp = Array(repeating: 0, count: A.count+1)
        if A[0] == "0" {
            return 0
        }
        dp[0] = 1
        if A[0] != "0" {
            dp[1] = 1
        }
        if A.count < 2 {
            return dp[A.count]
        }
        for i in 2...A.count {
            if Int(String(A[i-1]))! > 0 {
                dp[i] = dp[i-1]
            }
            let number = Int(String(A[i-2]))! * 10 + Int(String(A[i-1]))!
            print(number)
            if number > 9 && number < 27 {
                dp[i] += dp[i-2] % 1000000007
            }
        }
        
        return dp[A.count] % 1000000007
    }
    
    var t = Array(repeating: -1, count: 1000)
    
    func stairs(_ A: Int) -> Int {
        if A == 0 {
            return 1
        }
        if A == 1 {
            return 1
        }
        if t[A] != -1 {
            return t[A]
        }
        let one = A-1
        let two = A-2
        t[A] = stairs(one) + stairs(two)
        return t[A]
    }
    
    func intersectingChords(_ A: Int) -> Int {
        let points = 2*A
        var dp = Array(repeating: 0, count: points+1)
        dp[0] = 1
        dp[2] = 1
        var i = 4
        while i <= points {
            var j = 0
            while j < i-1 {
                print(i)
                dp[i] += dp[j]*dp[i-2-j] % 1000000007
                j+=2
            }
            i+=2
        }
        return dp[points] % 1000000007
    }
    
    
    
    
    func lisString(_ A: [Int]) -> Int {
        var lis = Array(repeating: 1, count: A.count)
        var maxCount = 1
        for i in 0..<A.count {
            for j in 0..<i {
                if A[i] > A[j] && lis[j]+1 > lis[i] {
                    lis[i] = lis[j]+1
                    maxCount = max(lis[i], maxCount)
                }
            }
        }
        return maxCount
    }
    
   
    func minJumps(_ A: [Int]) -> Int {
        var jumps = Array(repeating: A.count+1, count: A.count)
        if A[0] == 0 && A.count > 1 {
            return -1
        }
        if A.count < 2 {
            return 0
        }
        jumps[0] = 0
        
        for i in 0..<A.count {
            if A[i] == 0 {
                continue
            }
            for j in 1...A[i] {
                if i+j < A.count && jumps[i] + 1 < jumps[i+j] {
                    jumps[i+j] = jumps[i] + 1
                }
            }
            print(jumps)
        }
        
        return jumps[A.count-1]
    }
    
    
    func canJump(_ A: [Int]) -> Int {
        var reachedSoFar = 0
        var current = 0
        while current < A.count && reachedSoFar >= current {
            reachedSoFar = max(A[current]+current, reachedSoFar)
             current += 1
        }
        print(A.count)
        print(current)
        print(reachedSoFar)
        if current == A.count {
            return 1
        }
        return 0
    }
    
}

let d58 = Day58()
var mat = [ 16, 0, 0, 0, 12, 1, 13, 1, 30, 0, 14, 0, 0, 3, 0, 0, 2, 0, 0, 0, 7, 0, 0, 0, 0, 16, 0, 14, 0, 22, 0, 0, 0, 5, 0, 0, 0, 0, 7, 0, 26, 0, 0, 13, 22, 0, 0, 0, 0, 22, 0, 0, 0, 16, 0, 0, 29, 0, 0, 0, 3, 0, 0, 0, 28, 0, 0, 0, 29, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 3, 0, 0, 0, 19, 0, 0, 15, 0, 0, 30, 0, 0, 0, 0, 0, 0, 12, 0, 19, 6, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 12, 0, 24, 16, 21, 0, 8, 0, 14, 6, 0, 0, 5, 23, 0, 22, 0, 15, 15, 0, 26, 0, 14, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 13, 0, 24, 0, 0, 16, 24, 0, 9, 0, 0, 0, 0, 0, 21, 0, 0, 25, 0, 0, 0, 0, 0, 27, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 0, 0, 0, 30, 10, 0, 18, 30, 0, 0, 0, 0, 0, 0, 19, 0, 0, 0, 0, 29, 0, 0, 0, 8, 7, 29, 16, 30, 0, 0, 3, 0, 0, 0, 17, 0, 0, 22, 0, 0, 0, 0, 0, 18, 0, 0, 11, 11, 0, 0, 0, 0, 11, 19, 2, 0, 0, 0, 2, 0, 16, 11, 21, 0, 10, 0, 29, 0, 0, 0, 0, 0, 1, 15, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 29, 0, 9, 0, 6, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 0, 0, 0, 11, 0, 0, 21, 0, 0, 0, 0, 4, 0, 0, 0, 0, 14, 21, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 21, 0, 0, 0, 0, 0, 0, 0, 0, 21, 0, 0, 14, 0, 0, 0, 0, 29, 24, 0, 4, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 25, 0, 9, 0, 0, 0, 0, 24, 21, 12, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 29, 2, 0, 0, 0, 22, 9, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 8, 29, 19, 0, 0, 0, 14, 24, 0, 22, 0, 24, 0, 0, 5, 0, 0, 0, 28, 0, 0, 29, 0, 0, 27, 13, 0, 18, 0, 0, 0, 0, 11, 11, 0, 0, 28, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0, 0, 0, 12, 0, 0, 12, 19, 23, 0, 20, 0, 8, 6, 23, 17, 14, 0, 0, 24, 3, 0, 0, 0, 6, 11, 24, 0, 0, 0, 0, 0, 0, 18, 0, 0, 1, 27, 0, 1, 0, 0, 0, 0, 0, 19, 0, 0, 0, 0, 11, 16, 0, 0, 24, 25, 0, 0, 17, 0, 0, 0, 0, 21, 0, 0, 0, 0, 0, 9, 19, 0, 0, 0, 0, 0, 0, 6, 0, 0, 5, 0, 15, 17, 14, 1, 27, 0, 0, 24, 16, 28, 0, 18, 0, 20, 20, 0, 29, 0, 2, 29, 0, 0, 17, 0, 30, 0, 0, 0, 0, 0, 29, 15, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 16, 0, 0, 0, 0, 0, 0, 18, 20, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 21, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 28, 11, 19, 0, 0, 25, 0, 0, 20, 0, 0, 0, 0, 0, 15, 0, 0, 6, 3, 4, 0, 0, 0, 0, 22, 0, 2, 0, 0, 0, 14, 0, 0, 5, 0, 18, 27, 0, 0, 0, 0, 0, 28, 0, 0, 0, 9, 0, 20, 4, 28, 0, 0, 4, 0, 0, 3, 0, 3, 9, 3, 0, 6, 0, 0, 0, 0, 0, 0, 13, 0, 23, 0, 0, 16, 5, 0, 27, 4, 0, 28, 0, 0, 0, 0, 0, 0, 0, 5, 0, 24, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 4, 10, 28, 0, 0, 0, 22, 14, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 0, 21, 0, 30, 0, 0, 19, 0, 0, 0, 0, 7, 0, 22, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 0, 0, 13, 29, 18, 0, 0, 0, 0, 0, 0, 0, 0, 29, 30, 0, 0, 0, 28, 0, 0, 18, 26, 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 27, 0, 0, 0, 0, 0, 0, 19, 0, 0, 0, 29, 16, 13, 0, 3, 0, 0, 11, 12, 7, 3, 0, 2, 0, 0, 16, 0, 0, 26, 0, 15, 0, 20, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 25, 3, 27, 0, 0, 0, 13, 0, 0, 0, 0, 22, 25, 0, 22, 25, 0, 17, 29, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 28, 8, 1, 0, 0, 0, 0, 0, 29, 15, 16, 0, 0, 0, 0, 0, 0, 23, 28, 0, 0, 0, 2, 0, 12, 27, 0, 22, 0, 0 ]
let ans = d58.canJump(mat)
for item in d58.t {
    print(item)
}

class Day56 {
   var t = [[Int]]()
    func longestCommonSubSequence(_ A: String, _ B: String) -> Int {
        t = Array(repeating: Array(repeating: -1, count: A.count+1), count: B.count+1)
        let firstString = Array(A)
        let secondString = Array(B)
        let res = lcsTopDown(firstString, secondString)//lcs(firstString, secondString, A.count, B.count, t: &t)
        return res
    }
    
    func longestCommonPalindrome(_ A: String) -> Int {
        t = Array(repeating: Array(repeating: -1, count: A.count+1), count: A.count+1)
        let firstString = Array(A)
        var secondString = Array(A)
        secondString = secondString.reversed()
        print(secondString)
        let res = lcsTopDown(firstString, secondString)//lcs(firstString, secondString, A.count, B.count, t: &t)
        return res
    }

    func editDistance(_ A: String,  _ B: String) -> Int {
        t = Array(repeating: Array(repeating: -1, count: B.count+1), count: A.count+1)
        let firstString = Array(A)
        let secondString = Array(B)
        let editDistance = editDistanceBottomUp(firstString, secondString, A.count, B.count, t: &t)
        return editDistance
    }
    
    func lcs(_ A: [Character], _ B: [Character], _ sizeA: Int, _ sizeB: Int, t: inout [[Int]]) -> Int {
        if sizeA == 0 || sizeB == 0 {
            return 0
        }
        if t[sizeA][sizeB] != -1 {
            return t[sizeA][sizeB]
        }
        if A[sizeA-1] == B[sizeB-1] {
            t[sizeA][sizeB] = 1 + lcs(A, B, sizeA-1, sizeB-1, t: &t)
            return t[sizeA][sizeB]
        }
        t[sizeA][sizeB] = max(lcs(A, B, sizeA-1, sizeB, t: &t), lcs(A, B, sizeA, sizeB-1, t: &t))
        return t[sizeA][sizeB]
    }
    
    func editDistanceBottomUp(_ A: [Character], _ B: [Character], _ sizeA: Int, _ sizeB: Int, t: inout [[Int]]) -> Int {
        if sizeA == 0 {
            return sizeB
        }
        if sizeB == 0 {
            return sizeA
        }
        
        if t[sizeA][sizeB] != -1 {
            return t[sizeA][sizeB]
        }
        if A[sizeA-1] == B[sizeB-1] {
            t[sizeA][sizeB] = editDistanceBottomUp(A, B, sizeA-1, sizeB-1, t: &t)
            return t[sizeA][sizeB]
        } else {
            t[sizeA][sizeB] = 1 + min(editDistanceBottomUp(A, B, sizeA, sizeB-1, t: &t), // Add
                                  min(editDistanceBottomUp(A, B, sizeA-1, sizeB-1, t: &t), // replace
                                      editDistanceBottomUp(A, B, sizeA-1, sizeB, t: &t))) // delete
            return t[sizeA][sizeB]
        }
        
    }
    
    
    func lcsTopDown(_ A: [Character], _ B: [Character]) -> Int {
         t = Array(repeating: Array(repeating: -1, count: B.count+1), count: A.count+1)
        for i in 0...A.count {
            for j in 0...B.count {
                if i == 0 || j == 0 {
                    t[i][j] = 0
                } else if A[i-1] == B[j-1] {
                    t[i][j] = 1 + t[i-1][j-1]
                } else {
                     t[i][j] = max(t[i-1][j],t[i][j-1])
                }
            }
        }
        return t[A.count][B.count]
    }
    
    func repeatingSubSequence(_ A: String) -> Int {
        t = Array(repeating: Array(repeating: -1, count: A.count+1), count: A.count+1)
        let firstString = Array(A)
        let res = longestRepeatingSubsequence(firstString, firstString, A.count, A.count, t: &t) >= 2 ? 1 : 0
        return res
    }
    
    func longestRepeatingSubsequence(_ A: [Character], _ B: [Character], _ sizeA: Int, _ sizeB: Int, t: inout [[Int]]) -> Int {
        if sizeA == 0 || sizeB == 0 {
            return 0
        }
        if t[sizeA][sizeB] != -1 {
            return t[sizeA][sizeB]
        }
        if A[sizeA-1] == B[sizeB-1] && sizeA-1 != sizeB-1 {
            t[sizeA][sizeB] = 1 + longestRepeatingSubsequence(A, B, sizeA-1, sizeB-1, t: &t)
            return  t[sizeA][sizeB]
        } else {
            t[sizeA][sizeB] = max(longestRepeatingSubsequence(A, B, sizeA-1, sizeB, t: &t), longestRepeatingSubsequence(A, B, sizeA, sizeB-1, t: &t))
            return t[sizeA][sizeB]
        }
    }
    
    
    func findSubsequenceCount(_ A: String, _ B: String) -> Int {
        t = Array(repeating: Array(repeating: -1, count: B.count+1), count: A.count+1)
        let firstString = Array(A)
        let secondString = Array(B)
        let res = findSubsequenceCountBottomUp(firstString, secondString, A.count, B.count, t: &t)
        return res
    }
    
    func findSubsequenceCountBottomUp(_ A: [Character], _ B: [Character], _ sizeA: Int, _ sizeB: Int, t: inout [[Int]] ) -> Int {
        if sizeB == 0 {
            return 1
        }
        if sizeA == 0 {
            return 0
        }
        if t[sizeA][sizeB] != -1 {
            return t[sizeA][sizeB]
        }
        if A[sizeA-1] != B[sizeB-1] {
            t[sizeA][sizeB] = findSubsequenceCountBottomUp(A, B, sizeA-1, sizeB, t: &t)
            return t[sizeA][sizeB]
        } else {
            t[sizeA][sizeB] = findSubsequenceCountBottomUp(A, B, sizeA-1, sizeB-1, t: &t) + findSubsequenceCountBottomUp(A, B, sizeA-1, sizeB, t: &t)
            return t[sizeA][sizeB]
        }
    }
    
    
    func isInterleaved(_ A: String, _ B: String, _ C: String) -> Int {
        let firstString = Array(A)
        let secondString = Array(B)
        let thirdString = Array(C)
        let res = isInterleavedTopDown(firstString, secondString, thirdString, A.count, B.count, C.count) ? 1 : 0
        return res
    }
    
    func isInterleavedTopDown(_ A: [Character], _ B: [Character], _ C: [Character], _ sizeA: Int, _ sizeB: Int, _ sizeC: Int) -> Bool {
        if sizeA + sizeB != sizeC {
             return false
        }
        if sizeA == 0 && sizeB == 0 {
            return sizeC == 0
        }
        if sizeB == 0 && sizeA != 0 {
            if A[sizeA-1] == C[sizeC-1] {
                return isInterleavedTopDown(A, B, C, sizeA-1, sizeB, sizeC-1)
            }
        } else if sizeA == 0 && sizeB != 0 {
            if B[sizeB-1] == C[sizeC-1] {
                return isInterleavedTopDown(A, B, C, sizeA, sizeB-1, sizeC-1)
            }
        }else if (A[sizeA-1] == C[sizeC-1]) && (B[sizeB-1] != C[sizeC-1]) {
            return isInterleavedTopDown(A, B, C, sizeA-1, sizeB, sizeC-1)
        } else if (A[sizeA-1] != C[sizeC-1]) && (B[sizeB-1] == C[sizeC-1]) {
            return isInterleavedTopDown(A, B, C, sizeA, sizeB-1, sizeC-1)
        } else if (A[sizeA-1] == C[sizeC-1]) && (B[sizeB-1] == C[sizeC-1]) {
            return isInterleavedTopDown(A, B, C, sizeA-1, sizeB, sizeC-1) || isInterleavedTopDown(A, B, C, sizeA, sizeB-1, sizeC-1)
        }
        return false
    }
    
    var dp = [[Bool]]()
    
    func regularExpressionMatch(_ A: String, _ B: String) -> Int {
        let firstString = Array(A)
        let secondString = Array(B)
        let res = patternMatching(firstString, secondString) ? 1 : 0
        return res
    }
    
   
    func patternMatching(_ A: [Character], _ B: [Character]) -> Bool {
        dp = Array(repeating: Array(repeating: false, count: B.count+1), count: A.count+1)
        for i in 0...A.count {
            for j in 0...B.count {
                if i==0 && j==0 {
                    dp[i][j] = true
                } else if i == 0 && j != 0 {
                    if B[j-1] == "*" {
                        dp[i][j] = dp[i][j-1]
                    }
                } else if i != 0 && j == 0 {
                    dp[i][j] = false
                } else if A[i-1] == B[j-1] || B[j-1] == "?" {
                    dp[i][j] = dp[i-1][j-1]
                } else if B[j-1] == "*" {
                    dp[i][j] = dp[i][j-1] || dp[i-1][j]
                }
            }
        }
        return dp[A.count][B.count]
    }
    
    
//    func patternMatchingII(_ A: [Character], _ B: [Character]) -> Bool {
//        dp = Array(repeating: Array(repeating: false, count: B.count+1), count: A.count+1)
//        for i in 0...A.count {
//            for j in 0...B.count {
//                if i==0 && j==0 {
//                    dp[i][j] = true
//                } else if i == 0 && j != 0 {
//                    if B[j-1] == "*" {
//                        dp[i][j] = dp[i][j-1]
//                    }
//                } else if i != 0 && j == 0 {
//                    dp[i][j] = false
//                } else if A[i-1] == B[j-1] || B[j-1] == "?" {
//                    dp[i][j] = dp[i-1][j-1]
//                } else if B[j-1] == "*" {
//                    dp[i][j] = dp[i][j-1] || dp[i-1][j]
//                }
//            }
//        }
//        return dp[A.count][B.count]
//    }
    
    
    
}

let d56 = Day56()
let d56A = d56.regularExpressionMatch("aab", "c*a*b")
for item in d56.dp {
    print(item)
}



















///========================================================================================================
///TreesMaps and Heaps
///========================================================================================================


class Day55 {
    
//    public static int[] maxPairCombinations(int[] A, int[] B) {
//        int n = A.length-1;
//        int[] res = new int[n+1];
//         PriorityQueue<Node> pq = new PriorityQueue<Node>(new Comparator<Node>() {
//                public  int compare(Node n1,Node n2){
//                    return n2.sum - n1.sum;
//                }
//         });
//
//        Arrays.sort(A);
//        Arrays.sort(B);
//        for(int i = 0; i<B.length; i++) {
//            pq.add(new Node(A[n] + B[i], n, i));
//        }
//        int count = 0;
//        while(count < n+1) {
//            res[count] = pq.peek().sum;
//            int i  = pq.peek().i;
//            int j  = pq.peek().j;
//            System.out.println(count + "value " + pq.peek().sum);
//            pq.remove();
//            count++;
//            if (count == n+1) { break; }
//            pq.add(new Node(A[i-1] + B[j], i-1,j));
//        }
//        return res;
//    }
    
    
    
//    public static int maxChocolate( int[] B, int A) {
//        PriorityQueue<Long> pq = new PriorityQueue<Long>(Collections.reverseOrder()) ;
//        int count  = 0;
//        for(int i = 0; i<B.length; i++) {
//            pq.add((long)B[i]);
//        }
//        long res = 0;
//        while(count < A) {
//            res = (res+ pq.peek()) % 1000000007;
//            long item = pq.remove();
//            pq.add(item/2);
//            count++;
//        }
//        return (int)(res%(Math.pow(10,9) +7));
//    }
    
//        public static ListNode megerKSortedList( ArrayList<ListNode> a) {
//        PriorityQueue<ListNode> pq = new PriorityQueue<ListNode>(new Comparator<ListNode>() {
//            public int compare(ListNode a, ListNode b) {
//                return a.val - b.val;
//            }
//        }) ;
//        int count  = 0;
//        for(int i = 0; i<a.size(); i++) {
//            pq.add(a.get(i));
//        }
//        ListNode res = new ListNode(0);
//        ListNode itr = res;
//        while(!pq.isEmpty()) {
//            ListNode temp = pq.remove();
//            ListNode next = temp.next;
//            if(next!=null) {
//                pq.add(next);
//            }
//            itr.next = temp;
//            itr = itr.next;
//        }
//        return res.next;
//    }
    
    
    
//    public static ArrayList<Integer> distinctElementsInWindow(int [] A, int B) {
//        HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
//        ArrayList<Integer> res = new ArrayList<Integer>();
//        int distinctElement = 0;
//        for(int i= 0; i < B; i++) {
//            if (map.get(A[i]) == null) {
//                distinctElement+=1;
//                map.put(A[i], 1);
//            } else {
//                map.put(A[i], map.get(A[i])+1);
//            }
//        }
//        res.add(distinctElement);
//        for(int i= B; i < A.length; i++) {
//            System.out.println("HashMap: " + map.toString() + "distinctElement:" + distinctElement);
//            int oldValueCount = map.get(A[i-B]);
//            if (oldValueCount == 1) {
//                distinctElement--;
//                map.remove(A[i-B]);
//            } else {
//                map.put(A[i-B], oldValueCount-=1);
//            }
//            if (map.get(A[i]) == null) {
//                distinctElement+=1;
//                map.put(A[i], 1);
//            } else {
//                map.put(A[i], map.get(A[i])+1);
//            }
//            System.out.println("HashMap: " + map.toString() + "distinctElement:" + distinctElement);
//            res.add(distinctElement);
//        }
//        return res;
//    }
    
}



















///========================================================================================================
///Trees
///========================================================================================================
class TreeNode : Equatable {
    static func == (lhs: TreeNode, rhs: TreeNode) -> Bool {
        lhs.val == rhs.val && lhs.left == rhs.left && rhs.right == lhs.right
    }
    
   var val: Int = 0
   var left: TreeNode?
   var right: TreeNode?
    var next: TreeNode?
    
    init(val: Int) {
        self.val = val
    }
}
var res = [Int]()
func inorder(_ A: TreeNode?) {
    if A == nil {
        return
    }
    //print("node is \(A?.val) left is \(A?.left?.val) right is \(A?.right?.val)")
    inorder(A?.left)
    print(A!.val)
    return inorder(A?.right)
}

func preorder(_ A: TreeNode?) {
    if A == nil {
        return
    }
    print(A!.val)
    preorder(A?.left)
    preorder(A?.right)
}

func postorder(_ A: TreeNode?) -> [Int] {
    if A == nil {
        return res
    }
    
    postorder(A?.left)
    postorder(A?.right)
    res.append(A!.val)
    return res
}

class Day54 {
    func flattenToLL(_ A: TreeNode?) -> TreeNode? {
        if A == nil {
            return nil
        }
        let left = flattenToLL(A?.left)
        let right = flattenToLL(A?.right)
        A?.left = nil
        A?.right = left
        var curr = A
        while curr?.right != nil {
            curr = curr?.right
        }
        curr?.right = right
        return A
    }
}









class Day53 {
    var ans = [[Int]]()
    func rootToLeafPaths(_ A: TreeNode?, _ sum: Int, _ res: inout [Int]) {
        if A == nil {
            return
        }
        if A?.left == nil  && A?.right == nil && sum - A!.val == 0 {
            res.append(A!.val)
            ans.append(res)
            res.popLast()
        }
        let nextSum = sum - A!.val
        res.append(A!.val)
        rootToLeafPaths(A?.left, nextSum, &res)
        rootToLeafPaths(A?.right, nextSum, &res)
        res.removeLast()
    }
    
    
    func maxDepth(_ A: TreeNode?) -> Int {
        if A == nil {
            return 0
        }
        let left = maxDepth(A?.left)
        let right = maxDepth(A?.right)
        return max(left, right) + 1
    }
    
    
    func minDepth(_ A: TreeNode?) -> Int {
        if A == nil {
            return 0
        }
        let left = minDepth(A?.left)
        let right  = minDepth(A?.right)
        
        if A?.left != nil && A?.right != nil {
            return min(left, right) + 1
        }
        if A?.left == nil { return right + 1}
        return left + 1
    }
    
    var sum  = 0
    func sumRootToLeafNumbers(_ A: TreeNode?, _ pathSum: Int) {
        if A == nil {
            return
        }
        let newPathSum = (pathSum*10 + A!.val) % 1003
        if A?.left == nil && A?.right == nil {
            sum = (sum + newPathSum) % 1003
            return
        }
        print(newPathSum)
        sumRootToLeafNumbers(A?.left, newPathSum)
        sumRootToLeafNumbers(A?.right, newPathSum)
    }
    
    
    var firstValue = false
    var secondValue = false
    func lCSBT(_ A: TreeNode?, _ B: Int, _ C: Int) -> Int {
        if A == nil {
            return -1
        }
        let left = lCSBT(A?.left, B, C)
        let right = lCSBT(A?.right, B, C)
        if A?.val == B || A?.val == C {
            if firstValue {
                secondValue = true
            } else {
                firstValue = true
            }
            return A!.val
        }

        if left != -1 && right != -1 {
            return A!.val
        }
        if left == -1 && right == -1 {
            return -1
        }
        return left != -1 ? left : right
    }
    
    
}

let D53Tree = TreeNode(val: 3)
//D53Tree.left = TreeNode(val: 5)
//D53Tree.right = TreeNode(val: 1)
//D53Tree.left?.left = TreeNode(val: 6)
//D53Tree.left?.right = TreeNode(val: 2)
//D53Tree.left?.right?.left = TreeNode(val: 7)
//D53Tree.left?.right?.right = TreeNode(val: 4)
//D53Tree.right?.left = TreeNode(val: 0)
//D53Tree.right?.right = TreeNode(val: 8)
//D53Tree.right?.right?.left = TreeNode(val: 5)
//D53Tree.right?.right?.right = TreeNode(val: 1)
var D53sum = 22
var pathSum = 0
let D53 = Day53()
var resARRAY = [Int]()

var D53res = D53.lCSBT(D53Tree, 2, 1)
print(D53.firstValue)
print(D53.secondValue)











class Day52 {
    func buildFromInOrderPostOrder(_ inOrder: [Int], _ postOrder: [Int], _ inStart: Int, _ inEnd: Int, _ postIndex: inout Int) -> TreeNode? {
        if inEnd < inStart {
            return nil
        }
        let node = TreeNode(val: postOrder[postIndex])
        postIndex -= 1
        if inStart == inEnd {
            return node
        }
        let index =  searchIndex(inOrder, inStart, inEnd, value: node.val)
        node.right = buildFromInOrderPostOrder(inOrder, postOrder, index+1, inEnd, &postIndex)
        node.left = buildFromInOrderPostOrder(inOrder, postOrder, inStart, index-1, &postIndex)
       
        return node
    }
    
    
    func searchIndex(_ inOrder: [Int],  _ inStart: Int, _ inEnd: Int, value: Int) -> Int {
        for index in inStart ... inEnd {
            if inOrder[index] == value {
                return index
            }
        }
        return -1
    }
    
    
    func buildFromInOrderPreOrder(_ inOrder: [Int], _ preOrder: [Int], _ inStart: Int, _ inEnd: Int, _ preIndex: inout Int) -> TreeNode? {
        if inEnd < inStart {
            return nil
        }
        let node = TreeNode(val: preOrder[preIndex])
        preIndex += 1
        if inStart == inEnd {
            return node
        }
        let index =  searchIndex(inOrder, inStart, inEnd, value: node.val)
        node.left = buildFromInOrderPreOrder(inOrder, preOrder, inStart, index-1, &preIndex)
        node.right = buildFromInOrderPreOrder(inOrder, preOrder, index+1, inEnd, &preIndex)
        return node
    }
    
    func invertTree(_ A: TreeNode?) -> TreeNode? {
        if A?.left == nil && A?.right == nil {
            return A
        }
        let node =  TreeNode(val: 0)
        node.val = A!.val
        //print("node is \(node.val) left is \(node.left?.val) right is \(node.right?.val)")
        let left = invertTree(A?.left)
        let right = invertTree(A?.right)
        
        node.left = right
        node.right = left
        
        //print("node is \(node.val) left is \(node.left?.val) right is \(node.right?.val)")
        return node
    }
    
    
    func pathSum(_ A: TreeNode?, _ B: inout Int) -> Bool {
        if A == nil {
            return B == 0
        }
        B = B - A!.val
        let left = pathSum(A?.left, &B)
        let right = pathSum(A?.right, &B)
        return left || right
    }
    
}

var D52 = Day52()
var inOrder =  [4, 8, 2, 5, 1, 6, 3, 7]
var postOrder = [8, 4, 5, 2, 6, 7, 3, 1]
var preOrder = [1,2,4,8,5,3,6,7]
var nCount =  postOrder.count-1
//var D52res = D52.buildFromInOrderPostOrder(inOrder, postOrder, 0 , inOrder.count-1, &nCount)


let D52Tree = TreeNode(val: 10)
D52Tree.left = TreeNode(val: 8)
D52Tree.right = TreeNode(val: 3)
D52Tree.left?.left = TreeNode(val: 3)
D52Tree.left?.right = TreeNode(val: 5)
D52Tree.right?.left = TreeNode(val: 2)
var D51sum = 2
var D52res = D52.pathSum(D52Tree, &D51sum)








class Day51 {
    func connectNodesAtSameLevel(_ A: TreeNode?) {
        A?.next = nil
        connectNodesAtSameLevelHelper(A)
    }
    
    func connectNodesAtSameLevelHelper(_ A: TreeNode?) {
        if A == nil {
            return
        }
        if A?.left != nil {
            A?.left?.next = A?.right
        }
        if A?.right != nil {
            A?.right?.next = A?.next != nil ? A?.next?.left : nil
        }
        connectNodesAtSameLevelHelper(A?.left)
        connectNodesAtSameLevelHelper(A?.right)
    }
    
    
    
    func connectNodesAtSameLevel2(_ A: TreeNode?) {
        if A == nil {
            return
        }
        var queue = [TreeNode]()
        queue.append(A!)
        while !queue.isEmpty {
            var size = queue.count
            while size > 0 {
                let current = queue.first!
                size -= 1
                if size > 1 {
                    current.next = queue.first
                } else {
                    current.next = nil
                }
                if current.left != nil {
                    queue.append(current.left!)
                }
                if current.right != nil {
                    queue.append(current.right!)
                }
            }
        }
    }
    
    
    
    func identicalBinaryTree(_ A: TreeNode?, _ B: TreeNode?) -> Bool {
        if A == nil && B == nil {
            return true
        }
        
        if (A == nil && B != nil) || A != nil && B == nil  {
            return false
        }
        
        return A?.val == B?.val && identicalBinaryTree(A?.left, B?.left) && identicalBinaryTree(A?.right, B?.right)
    }
    
    
    func isSymmetric(_ A: TreeNode?) -> Int {
        if A == nil {
            return 1
        }
        let res = isSymmetricBinaryTree(A, A) ? 1 : 0
        return res
    }
    
    func isSymmetricBinaryTree(_ A: TreeNode?, _ B: TreeNode?) -> Bool {
        if A == nil && B == nil {
            return true
        }
       if (A == nil && B != nil) || A != nil && B == nil  {
            return false
        }
        let left  = isSymmetricBinaryTree(A?.left, B?.right)
        let right =  isSymmetricBinaryTree(A?.right, B?.left)
        return A?.val == B?.val &&  left && right
    }
}


var T6A = TreeNode(val: 1)
T6A.left = TreeNode(val: 2)
T6A.right = TreeNode(val: 3)
T6A.left?.left = TreeNode(val: 7)
T6A.left?.right = TreeNode(val: 6)
T6A.right?.left = TreeNode(val: 5)
T6A.right?.right = TreeNode(val: 4)
T6A.right?.left?.right = TreeNode(val: 8)
//T5A.right?.right?.right = TreeNode(val: 8)
//T5A.right?.right?.right = TreeNode(val: 9)
//T5A.right?.right?.right?.right = TreeNode(val: 10)
//T5A.right?.left?.right = TreeNode(val: 8)
var D51 = Day51()
var D51res = D51.isSymmetric(T6A)
print(D51res)











class Day50 {
    func cousinInBT(_ A: TreeNode?, _ B: Int) -> [Int] {
        var res = [Int]()
        var valueFound = false
        if A == nil {
            return []
        }
        if A!.val == B {
            return []
        }
        var queue = [TreeNode]()
        queue.append(A!)
        while !queue.isEmpty && !valueFound {
            var size = queue.count
            while size > 0 {
                //                for item in queue {
                //                    print(item.val)
                //                }
                //                print("       ")
                size -= 1
                let curr = queue.first!
                queue.remove(at: 0)
                if  curr.left?.val == B || curr.right?.val == B {
                    valueFound = true
                } else {
                    if curr.left != nil {
                        queue.append(curr.left!)
                    }
                    if curr.right != nil {
                        queue.append(curr.right!)
                    }
                }
            }
        }
        
        if valueFound {
            while !queue.isEmpty {
                res.append(queue.first!.val)
                queue.remove(at: 0)
            }
        }
        return res
    }
    
    
    
    
    func rightViewBT(_ A: TreeNode?) -> [Int] {
        var res = [Int]()
        if A == nil {
            return []
        }
        var queue = [TreeNode]()
        queue.append(A!)
        while !queue.isEmpty {
            var size = queue.count
//            print("QUEUE")
//            for item in queue {
//                print(item.val)
//            }
//            print("       ")
            while size > 0 {
                let curr = queue.first!
                if size == 1 {
                    res.append(curr.val)
                }
                size -= 1
                queue.remove(at: 0)
//                print("left : \(curr.left?.val) & right : \(curr.right?.val)")
                if curr.left != nil {
                    queue.append(curr.left!)
                }
                if curr.right != nil {
                    queue.append(curr.right!)
                }
//                print("resuly : \(res)")
            }
        }
        return res
    }
    
    func zingZagTraversal(_ A: TreeNode?) -> [[Int]] {
        var res = [[Int]]()
        if A == nil {
            return []
        }
        var stack1 = [TreeNode]()
        var stack2 = [TreeNode]()
        stack1.append(A!)
        while !stack1.isEmpty || !stack2.isEmpty {
            var row = [Int]()
            while !stack1.isEmpty {
                let curr = stack1.last
                row.append(curr!.val)
                stack1.removeLast()
                if curr?.left != nil {
                    stack2.append(curr!.left!)
                }
                if curr?.right != nil {
                    stack2.append(curr!.right!)
                }
            }
             if row.count > 0 {  res.append(row) }
            row.removeAll()
            while !stack2.isEmpty {
                let curr = stack2.last
                stack2.removeLast()
                row.append(curr!.val)
                if curr?.right != nil {
                    stack1.append(curr!.right!)
                }
                if curr?.left != nil {
                    stack1.append(curr!.left!)
                }
            }
            if row.count > 0 {  res.append(row) }
        }
        return res
    }
    
    
}
var T5A = TreeNode(val: 1)
T5A.left = TreeNode(val: 2)
T5A.right = TreeNode(val: 3)
T5A.left?.left = TreeNode(val: 7)
T5A.left?.right = TreeNode(val: 6)
T5A.right?.left = TreeNode(val: 5)
T5A.right?.right = TreeNode(val: 4)
T5A.right?.left?.right = TreeNode(val: 8)
//T5A.right?.right?.right = TreeNode(val: 8)
//T5A.right?.right?.right = TreeNode(val: 9)
//T5A.right?.right?.right?.right = TreeNode(val: 10)
//T5A.right?.left?.right = TreeNode(val: 8)
var D50 = Day50()
var D50res = D50.zingZagTraversal(T5A)
print(D50res)










class Day49 {
    var map = [Int : [Int]]()
    func verticalOrderTraversal(_ A: TreeNode?, _ distance: Int) {
        if A == nil {
            return
        }
        var res = [Int]()
        if map[distance] != nil {
            res =  map[distance]!
            res.append(A!.val)
        } else {
            res = [A!.val]
        }
        map[distance] = res
        verticalOrderTraversal(A?.left, distance-1)
        verticalOrderTraversal(A?.right,distance+1)
    }
    
    func solve(_ A: TreeNode?) -> [Int] {
        var res = [Int]()
        horizontalOrderTraversal(A, 0)
        let sortedKeys =  map.keys.sorted()
        for key in sortedKeys {
            res.append(contentsOf: map[key]!)
        }
        return res
        
    }
    
    
    func horizontalOrderTraversal(_ A: TreeNode?, _ distance: Int) {
        if A == nil {
            return
        }
        var res = [Int]()
        if map[distance] != nil {
            res =  map[distance]!
            res.append(A!.val)
        } else {
            res = [A!.val]
        }
        map[distance] = res
        horizontalOrderTraversal(A?.left, distance+1)
        horizontalOrderTraversal(A?.right,distance)
    }
}

var T4A = TreeNode(val: 8)
T4A.left = TreeNode(val: 3)
T4A.right = TreeNode(val: 10)
T4A.left?.left = TreeNode(val: 1)
//T4A.left?.left = TreeNode(val: 6)
T4A.right?.left = TreeNode(val: 6)
T4A.right?.right = TreeNode(val: 14)
T4A.right?.right?.left = TreeNode(val: 13)
T4A.right?.left?.right = TreeNode(val: 7)
T4A.right?.left?.left = TreeNode(val: 4)
var D49 = Day49()
var D49res = postorder(T4A)
print(D49res)




class Day47 {
    func removeHalfNode(_ A: TreeNode?) -> TreeNode? {
        if A ==  nil {
            return nil
        }
        let left = removeHalfNode(A?.left)
        let right = removeHalfNode(A?.right)
        if left != nil && right != nil {
            A?.left = left
            A?.right = right
            return A
        } else if left != nil {
            return left
        } else if A?.right != nil {
            return right
        }
        return A
    }
    
    
    var res = [Int]()
    func pathToNode(_ A: TreeNode?, _ B: Int) -> [Int] {
        if A == nil {
            return []
        }
        res.append(A!.val)
        //print(res)
        if A?.val == B {
            return res
        }
        if !pathToNode(A?.left, B).isEmpty || !pathToNode(A?.right, B).isEmpty {
            return res
        }
        res.removeLast()
        return []
    }
    
    func isBalanced(_ A: TreeNode?)-> Int {
        var height = 0
        let ans = isBalancedHelper(A, &height) ? 1 : 0
        return ans
    }
    
    
    func isBalancedHelper(_ A: TreeNode?, _ height: inout Int) -> Bool{
        if A == nil {
            height = 0
            return true
        }
        var lHeight = 0
        var rHeight = 0
        let left  = isBalancedHelper(A?.left , &lHeight)
        let right = isBalancedHelper(A?.right , &rHeight)
//        print("\(A?.val) : \(lHeight)")
//        print("\(A?.val) : \(rHeight)")
        height  =  max(lHeight, rHeight) + 1
        let heightUnBalanced = abs(lHeight-rHeight) >= 2
        if heightUnBalanced {
            return false
        }
        return left && right
    }
    
    
    
}

var T3A = TreeNode(val: 2)
//T3A.left = TreeNode(val: 7)
T3A.right = TreeNode(val: 2)
//T3A.left?.right = TreeNode(val: 6)
//T3A.left?.right?.left = TreeNode(val: 1)
//T3A.left?.right?.right = TreeNode(val: 11)
//T3A.right?.right = TreeNode(val: 9)
//T3A.right?.right?.left = TreeNode(val: 4)


//var T3B = TreeNode(val: 2)
//var T3C = TreeNode(val: 3)
//var T3D = TreeNode(val: 4)
//var T3E = TreeNode(val: 5)
//var T3F = TreeNode(val: 6)
//T3E.left = TreeNode(val: 8)
//T3E.right = TreeNode(val: 9)
//T3D.right = TreeNode(val: 7)
//T3A.left = T3B
//T3A.right = T3C
//T3C.left = T3E
//inorder(T3A)
print( "            ")
var ans = Day47().isBalanced(T3A)
//inorder(ans)


class Day46 {
    var ans = 0
    var map = Set<Int>()
    
    func TwoSum(_ A: TreeNode?, _ B: inout Int) -> Int {
        let ans = inorder(A, &B)
        return ans
    }
    
    func inorder(_ A: TreeNode?, _ B: inout Int) -> Int {
        if A == nil {
            return 0
        }
        inorder(A?.left, &B)
        let diff = B - A!.val
        if map.contains(diff) {
            return 1
        } else {
            map.insert(A!.val)
        }
        return inorder(A?.right, &B)
    }
    
    var prev: TreeNode?
    var first: TreeNode?
    var middle: TreeNode?
    var last: TreeNode?
    func BSTRecovery(_ A: TreeNode?) {
        var res = [Int]()
        BSTRecoveryHelper(A)
        if first != nil && last != nil {
            res.append(first!.val)
            res.append(last!.val)
            let temp = first!.val
            first!.val = last!.val
            last!.val = temp
        } else if first != nil && middle != nil {
            res.append(first!.val)
            res.append(middle!.val)
            let temp = first!.val
            first!.val = middle!.val
            middle!.val = temp
        }
        //return res
    }
    func BSTRecoveryHelper(_ head: TreeNode?) {
        if head == nil {
            return
        }
        BSTRecoveryHelper(head?.left)
        if prev != nil && head!.val < prev!.val {
            if first == nil {
                first = prev
                middle = head
            } else {
                last = head
            }
        }
        prev = head
        BSTRecoveryHelper(head?.right)
    }
    
}


var T2A = TreeNode(val: 2)
T2A.left = TreeNode(val: 1)
T2A.right = TreeNode(val: 3)
var T2B = 3
Day46().TwoSum(T2A, &T2B)







class Day45 {
    var ans = 0

    func kthsmallest(_ A: TreeNode?, _ B: inout Int) -> Int {
        inorder(A, &B)
        return ans
    }
    
    func inorder(_ A: TreeNode?, _ B: inout Int) {
        if A == nil {
            return
        }
        inorder(A?.left, &B)
        B -= 1
        if B == 0 {
            print(A?.val)
            ans = A!.val
        }
        inorder(A?.right, &B)
    }
}

var T1A = TreeNode(val: 3)
T1A.left = TreeNode(val: 1)
//T1A.right = TreeNode(val: 3)
var b = 1
Day45().inorder(T1A, &b)








///========================================================================================================
class Day44 {
//    func recurringFraction(_ A: Int, _ B: Int) -> String {
//        var ans = ""
//        if B == 0 {
//            return ans
//        }
//        var map = [Double : Int]()
//        let fraction = A/B
//        ans.append(String(fraction))
//        var remainder = Double(A) / Double(B)
//        remainder
//        while fraction != 0 && map[remainder] != nil {
//            map[fraction] = ans.count
//        }
//        return ans
//    }
}
Day44().recurringFraction(2, 3)


class Day43 {
//    public static int pointsOnALine(ArrayList<Integer> a, ArrayList<Integer> b) {
//        int max = Integer.MIN_VALUE;
//        for(int i = 0; i<a.size(); i++) {
//            int x1 = a.get(i) ;
//            int y1 = b.get(i) ;
//            // not global because we want to avoid extra addition.
//            HashMap<Double, Integer> map = new HashMap<Double, Integer>();
//            int samePoint = 1;
//            int infValue = 0;
//            for(int j = i+1; j<a.size(); j++) {
//               int x2 = a.get(j) ;
//               int y2 = b.get(j) ;
//               if((x1 == x2)&&(y1==y2)) {
//                   samePoint += 1;
//               } else if(x2 - x1 == 0) {
//                   infValue++;
//               } else {
//                   double slope = 0.0;
//                   if(y1 != y2) {
//                      slope = (double)(y2-y1)/(double)(x2-x1);
//                   }
//                   System.out.println("Slope:" + slope);
//                   if(map.containsKey(slope)) {
//                       map.put(slope, map.get(slope) + 1);
//                       int count = map.get(slope);
//                       System.out.println("count:" + count);
//                   } else {
//                       map.put(slope, 1);
//                   }
//               }
//            }
//            if((infValue + samePoint)  > max) {
//                System.out.println("infValue:" + infValue);
//                max = infValue+samePoint;
//            }
//            // for(Double key : map.keySet() ){
//            //     System.out.println("key:" + key);
//            // }
//            for(Integer value : map.values() ){
//                System.out.println("samePoint:" + samePoint);
//                System.out.println("value:" + value);
//                max = Math.max(value+samePoint, max);
//            }
//        }
//        return max;
//    }
}




class Day42 {
    func equal(_ A: [Int]) -> [Int] {
        var map = [Int : (Int,Int)]()
        var res =  Array(repeating: A.count, count: 4)
        for i in 0..<A.count-1 {
            for j in i+1 ..< A.count {
                let sum = A[i] + A[j]
                if map[sum] != nil {
                    let first = map[sum]!.0
                    let second = map[sum]!.1
                    let third = i
                    let forth = j
                    let condition1 = first < res[0]
                    let condition2 = first == res[0] && second < res[1]
                    let condition3 = first == res[0] && second == res[1] && third < res[2]
                    let condition4 = first == res[0] && second == res[1] && res[2] == third &&  forth < res[3]
                    if (first < i && second != third && second != forth && (condition1 || condition2 || condition3 || condition4)) {
                        res[0] = first
                        res[1] = second
                        res[2] = third
                        res[3] = forth
                    }
                    print(res)
                } else {
                    map[sum] = (i,j)
                }
            }
        }
        if res[0] == A.count {
            return [Int]()
        }
        return res
    }
    
    func longestNonRepeatingSubstringN2(_ A: String) -> Int {
        var maxLength = 1
        let charArray  = Array(A)
        for i in 0..<charArray.count {
            var set = Set<Character>()
            set.insert(charArray[i])
            for j in i+1 ..< charArray.count {
                if set.contains(charArray[j]) {
                    break
                } else {
                    set.insert(charArray[j])
                    maxLength = max(maxLength, j-i + 1)
                }
            }
        }
        return maxLength
    }
    
    func longestNonRepeatingSubstring(_ A: String) -> Int {
        var windowSize = 1
        let charArray  = Array(A)
        var start = 0
        var end = 0
        var set = Set<Character>()
        while start < charArray.count && end <  charArray.count {
            if !set.contains(charArray[end]) {
                set.insert(charArray[end])
                end+=1
                windowSize = max(windowSize, end-start)
            } else {
                set.remove(charArray[start])
                start+=1
            }
        }
        return windowSize
    }
}

var D42A = "ABDEFGABEF"//[ 1, 5, 2, 4, 2, 0, 2, 5, 1, 0, 5, 0 ]

//Day42().equal(D42A)
print(Day42().longestNonRepeatingSubstring(D42A))








class Day41 {
    func valisSudoKu(_ A: [[Int]]) -> Bool {
        var rows = Array(repeating: 0, count: 9)
        var cols = Array(repeating: 0, count: 9)
        var squares = Array(repeating: 0, count: 9)
        for row in 0..<A.count {
            for col in 0..<A[0].count {
                if A[row][col] == 0 {
                    continue
                }
                let value = 1<<(A[row][col]-1)
                if value & rows[row] > 0 {return false}
                if value & cols[col] > 0 {return false}
                if value & squares[3*(row/3) + col/3] > 0 {return false}
                rows[row] = rows[row] | value
                cols[col] = cols[col] | value
                squares[3*(row/3) + col/3]  =  squares[3*(row/3) + col/3] | value
            }
            
        }
        return true
    }
    
    func valisSudoKu(_ A: [String]) -> Int {
        var set = Set<String>()
        for row in 0..<9 {
            for col in 0..<9 {
                var column  =  A[row].index(A[0].startIndex, offsetBy: col)
                let character = A[row][column]
                if  character != "." {
                    if set.contains("\(character) is in row \(row)") || set.contains("\(character) is in column \(column)") || set.contains("\(character) is in square \(row/3) - \(col/3)"){
                        return 0;
                    } else {
                        set.insert("\(character) is in row \(row)")
                        set.insert("\(character) is in column \(column)")
                        set.insert("\(character) is in square \(row/3) - \(col/3)")
                    }
                }
                
            }
        }
        return 1
    }
    
    
    func differencePossible(_ A: inout [Int], _ B: Int) -> Int {
        A.sort()
        var first = 0
        var second = 1
        while(first < A.count && second < A.count) {
            let diff = A[second] - A[first]
            if diff == B && second != first {
                return 1
            } else if diff > B {
                first += 1
            } else {
                second += 1
            }
        }
        return 0
    }
    
    func differencePossible2(_ A: [Int], _ B: Int) -> Int {
        var set = Set<Int>()
        for index in 0..<A.count {
            let val = B+A[index]
            if set.contains(val) || set.contains((A[index] - B)) {
                return 1
            } else {
                set.insert(A[index])
            }
        }
        return 0
    }
    
    
    func anagrams(_ A: [String]) -> [[Int]] {
        var visited = Array(repeating: false, count: A.count)
        var res = [[Int]]()
        for i in  0..<A.count {
            print(i)
            if visited[i] == false {
                print(i)
                var row = [i+1]
                visited[i] = true
                
                for j in i+1..<A.count {
                    if anagram(A[i], A[j]) {
                        visited[j] = true
                        row.append(j+1)
                    }
                }
                res.append(row)
            }
        }
        return res
    }
    
    func anagram(_ A: String, _ B: String) -> Bool {
        if A.count != B.count {
            return false
        }
        let CA = A.sorted()
        let CB = B.sorted()
        for index in 0..<CA.count {
            if CA[index] != CB[index] {
                return false
            }

        }
        return true
    }
    
    func checkAnagram(_ A: String, _ B: String) -> Bool {return false}
}
var D41A =  [ "abbbaabbbabbbbabababbbbbbbaabaaabbaaababbabbabbaababbbaaabbabaabbaabbabbbbbababbbababbbbaabababba", "abaaabbbabaaabbbbabaabbabaaaababbbbabbbaaaabaababbbbaaaabbbaaaabaabbaaabbaabaaabbabbaaaababbabbaa", "babbabbaaabbbbabaaaabaabaabbbabaabaaabbbbbbabbabababbbabaabaabbaabaabaabbaabbbabaabbbabaaaabbbbab", "bbbabaaabaaaaabaabaaaaaaabbabaaaabbababbabbabbaabbabaaabaabbbabbaabaabaabaaaabbabbabaaababbaababb", "abbbbbbbbbbbbabaabbbbabababaabaabbbababbabbabaaaabaabbabbaaabbaaaabbaabbbbbaaaabaaaaababababaabab", "aabbbbaaabbaabbbbabbbbbaabbababbbbababbbabaabbbbbbababaaaabbbabaabbbbabbbababbbaaabbabaaaabaaaaba", "abbaaababbbabbbbabababbbababbbaaaaabbbbbbaaaabbaaabbbbbbabbabbabbaabbbbaabaabbababbbaabbbaababbaa", "aabaaabaaaaaabbbbaabbabaaaabbaababaaabbabbaaaaababaaabaabbbabbababaabababbaabaababbaabbabbbaaabbb" ]

Day41().anagrams(D41A)
print(Day41().anagrams(D41A))










/// ==== LInked List =====


class ListNode: Equatable {
    
    static func == (lhs: ListNode, rhs: ListNode) -> Bool {
        return lhs == rhs
    }
    
    var val: Int = 0
    var next: ListNode?
    
    init(value : Int) {
        self.val = value
    }
    
 }

func printList(_ A: ListNode?) {
    var head = A
    while (head != nil ) {
        print(head!.val)
        head = head?.next
    }
}















class Day39 {
    func merge(_ A: ListNode?, _ B: ListNode?) -> ListNode? {
        var result: ListNode? = nil
        if A == nil {
            return B
        }
        if B == nil {
            return A
        }
        
        if A!.val <= B!.val {
            result = A
            result?.next = merge(A?.next, B)
        } else {
            result = B
            result?.next = merge(A, B?.next)
        }
        return result
    }
    
    func mergeSort(_ A: ListNode?) -> ListNode? {
        if A == nil || A?.next == nil {
            return A
        }
        let middle = getMiddle(A)
        let secondHead = middle?.next
        middle?.next = nil
        let left = mergeSort(A)
        let right = mergeSort(secondHead)
        let sortedList = merge(left, right)
        return sortedList
    }
    
    func getMiddle(_ A: ListNode?) -> ListNode? {
        if A == nil {
            return nil
        }
        var slow = A
        var fast = A?.next
        while fast != nil && fast!.next != nil {
            slow = slow?.next
            fast = fast?.next?.next
        }
        
        return slow
        
    }
}

var D39A  = ListNode(value: 15)
D39A.next = ListNode(value: 12)
D39A.next?.next = ListNode(value: 3)
D39A.next?.next?.next = ListNode(value: 4)
D39A.next?.next?.next?.next = ListNode(value: 51)
D39A.next?.next?.next?.next?.next = ListNode(value: 16)
D39A.next?.next?.next?.next?.next?.next = ListNode(value: 7)
D39A.next?.next?.next?.next?.next?.next?.next = ListNode(value: 8)

var R39A = Day39().mergeSort(D39A)
printList(R39A)














class Day38 {
    
    func reaarrange(_ A: ListNode?) -> ListNode? {
        let ans = ListNode(value: 0)
        var slow = A
        var fast = slow?.next
        
        while fast?.next != nil && fast != nil {
            slow = slow!.next
            fast = fast!.next?.next
        }
        let secondHalf = reverse(slow?.next)
        slow?.next = nil
        //printList(A)
        var first = A
        var second = secondHalf
        var curr = ans
        while first != nil || second != nil {
            if first != nil {
                curr.next = first
                first = first?.next
                curr = curr.next!
            }
            if second != nil {
                curr.next = second
                second = second?.next
                curr = curr.next!
            }
        }
        return ans.next
    }
    
    
    
    func reverse(_ A: ListNode?) -> ListNode? {
        
        var prev: ListNode? = nil
        var curr = A
        while curr != nil  {
            let next = curr?.next
            curr!.next = prev
            prev = curr
            curr = next
        }
        return prev
    }
    
    
    func reverseSublist(_ A: ListNode?, _ B: inout Int, _ C: inout Int) -> ListNode? {
        let ans = ListNode(value: 0)
        ans.next = A///====
        var current  = A
        var index = 1
        var sublistPrev: ListNode? = nil
        var sublistNext: ListNode? = nil
        var sublistHead: ListNode? = nil
        var sublistTail: ListNode? = nil
        if B == C {
            return A
        }
        while current != nil && index <= C {
            if index < B {
                sublistPrev = current
            }
            if index == B {
                sublistHead = current
            }
            if index == C {
                sublistTail = current
                sublistNext = current?.next
            }
            index += 1
            current = current!.next
        }
        sublistTail?.next = nil
        sublistTail = reverse(sublistHead)
        if sublistPrev != nil {
            sublistPrev?.next = sublistTail
        } else {
            ans.next = sublistTail
        }
        sublistHead?.next = sublistNext
        return ans.next
    }
}












class Day37 {
    func partition(_ A: ListNode?, _ B: Int) -> ListNode? {
        let firstHead = ListNode(value: 0)
        var first = firstHead
        let secondHead = ListNode(value: 0)
        var second =  secondHead
        var head = A
        var firstCount = 0
        var length = 0
        var secondCount = 0
        while(head != nil) {
            if head!.val < B {
                first.next = head
                head = head!.next
                first = first.next!
                first.next = nil
                firstCount += 1
            } else {
                second.next = head
                head = head!.next
                second = second.next!
                second.next = nil
                secondCount += 1
            }
            length += 1
        }

        if firstCount == length {
            return firstHead.next
        } else if secondCount == length {
            return secondHead.next
        }
        if secondHead.next != nil {
            first.next = secondHead.next
        }
        
        return firstHead.next
    }
    
    func insertSort(_ A: ListNode? ) -> ListNode? {
        var ans : ListNode?
        var curr = A
        while(curr != nil) {
            let next = curr?.next
            ans = sortedInsert(ans, curr!.val)
            curr = next
        }
        return ans
    }
    
    func sortedInsert(_ A: ListNode?, _ B: Int) -> ListNode? {
        var head = A
        if head == nil {
            let temp  = ListNode(value: 0)
            temp.val = B
            temp.next = head
            return temp
        }
        
        if B < head!.val {
            let temp  = ListNode(value: 0)
            temp.val = B
            temp.next = head
            return temp
        }
        
        while head!.next != nil && head!.next!.val < B {
            head = head?.next
        }
        let temp  = ListNode(value: 0)
        temp.val = B
        temp.next = head?.next
        head?.next = temp
        return A
    }
    
}
var D37A  = ListNode(value: 300)
D37A.next = ListNode(value: 183)
D37A.next?.next = ListNode(value: 63)
D37A.next?.next?.next = ListNode(value: 465)
//D37A.next?.next?.next?.next = ListNode(value: 6)
//D37A.next?.next?.next?.next?.next = ListNode(value: 6)
//D37A.next?.next?.next?.next?.next?.next = ListNode(value: 7)
//D37A.next?.next?.next?.next?.next?.next?.next = ListNode(value: 8)
var D37R = Day37().insertSort(D37A)
printList(D37R)








class Day36 {
    func add2Lists(_ A: ListNode?, _ B: ListNode?) -> ListNode? {
        var firstptr = A
        var secondptr = B
        let ans = ListNode(value: 0)
        var head = ans
        var carry = 0
        
        while firstptr != nil && secondptr != nil {
            
            
            let first = firstptr!.val
            let second = secondptr!.val
            let sum = first + second + carry
            carry = sum / 10
            let sumNode = ListNode(value: 0)
            sumNode.val = sum % 10
            head.next = sumNode
            head = head.next!
            firstptr = firstptr?.next
            secondptr = secondptr?.next
        }
        
        if firstptr == nil && secondptr != nil {
            while secondptr != nil {
                let second = secondptr!.val
                let sum = second + carry
                carry = sum / 10
                let sumNode = ListNode(value: 0)
                sumNode.val = sum % 10
                head.next = sumNode
                head = head.next!
                secondptr = secondptr?.next
            }
            
        }
        
        if secondptr == nil && firstptr != nil {
            while firstptr != nil {
                let first = firstptr!.val
                let sum = first + carry
                carry = sum / 10
                let sumNode = ListNode(value: 0)
                sumNode.val = sum % 10
                head.next = sumNode
                head = head.next!
                firstptr = firstptr?.next
            }
        }
        if carry != 0 {
            let sumNode = ListNode(value: 0)
            sumNode.val = carry
            head.next = sumNode
        }
        return ans.next
    }
    
    
    func cycleDetection(_ A: ListNode?) -> Bool {
        var slow = A
        var fast = A
        var flag = false
        var count = 0 
        while slow != nil && fast != nil && fast?.next != nil {
            slow = slow?.next
            fast = fast?.next?.next
            if slow == fast {
                flag = true
                break
            }
            count += 1
            print(count)
        }
        return flag
    }
    
    
}


var D36A  = ListNode(value: 1)
D36A.next = ListNode(value: 5)
D36A.next?.next = ListNode(value: 9)
D36A.next?.next?.next = ListNode(value: 4)
D36A.next?.next?.next?.next = ListNode(value: 6)
D36A.next?.next?.next?.next?.next = ListNode(value: 6)
D36A.next?.next?.next?.next?.next?.next = ListNode(value: 7)
D36A.next?.next?.next?.next?.next?.next?.next = ListNode(value: 8)
//printList(D35A)
var D36B  = ListNode(value: 9)
D36B.next = ListNode(value: 9)
D36B.next?.next = ListNode(value: 9)
//D36B.next?.next?.next = ListNode(value: 4)
//D36B.next?.next?.next?.next = ListNode(value: 5)
//D36B.next?.next?.next?.next?.next = ListNode(value: 6)
//D36B.next?.next?.next?.next?.next?.next = ListNode(value: 7)
//D36B.next?.next?.next?.next?.next?.next?.next = ListNode(value: 8)

var b2 = Day36().cycleDetection(D36A)
//printList(b2)













class Day35 {
    func reverseKNode(_ A: ListNode?, K: Int) -> ListNode? {
        if A == nil {
            return nil
        }
        var prev: ListNode? = nil
        var current = A
        var k = K
        var next: ListNode? = nil
        while k > 0 && current != nil {
            next = current?.next
            current?.next = prev
            prev = current
            current = next
            k -= 1
        }
        if next != nil {
            A?.next = reverseKNode(next, K: K)
        }
        
        
        return prev
    }
    
    func pairWiseSwap(_ A: ListNode?) -> ListNode? {
        var current = A
        while current != nil && current?.next != nil {
            let temp = current!.val
            current!.val = current!.next!.val
            current?.next?.val = temp
            current = current!.next!.next
        }
        return A
    }
    
    func rotate(_ A: ListNode?, _ B: inout Int) -> ListNode? {
        let newHead = ListNode(value: 0)
        newHead.next = A
        var current = A
        var count = 0
        while (current != nil) {
            current = current?.next
            count+=1
        }
        let rotation = B%count
        if count == 1 || rotation == 0 {
            return A
        }
        var next: ListNode? = nil
        
        count = count-rotation-1
        current = A
        while count > 0 && current != nil {
            current = current?.next
            count -= 1
        }
        //        if B == 0 {
        //            prev?.next = nil
        //            newHead.next = current
        //        }
        //        while current?.next != nil {
        //            current = current?.next
        //        }
        //        current?.next = A
        if count == 0 {
            next = current?.next
            newHead.next = current?.next
            current?.next = nil
            
        }
        while next?.next != nil {
            next = next?.next
        }
        next?.next = A
        return newHead.next
    }
    
}

var D35A  = ListNode(value: 1)
D35A.next = ListNode(value: 2)
D35A.next?.next = ListNode(value: 3)
D35A.next?.next?.next = ListNode(value: 4)
D35A.next?.next?.next?.next = ListNode(value: 5)
D35A.next?.next?.next?.next?.next = ListNode(value: 6)
//D35A.next?.next?.next?.next?.next?.next = ListNode(value: 7)
//D35A.next?.next?.next?.next?.next?.next?.next = ListNode(value: 8)
//printList(D35A)
var z = 90
var b = Day35().rotate(D35A, &z)
printList(b)




class Day34 {
    func removeDuplicates(_ A: ListNode?) {
        var prev = A
        var curr = A
        
        while(curr != nil) {
            if curr!.val != prev!.val {
                prev!.next = curr
                prev = prev!.next
            }
            curr = curr!.next
        }
        prev?.next = nil
       // printList(A)
    }
    
    func removeAllDuplicateOccurances(_ A: ListNode?) -> ListNode? {
        var prev =  ListNode(value: -1)
        var curr = A
        var next = A?.next
        var head: ListNode? = nil
        var itr: ListNode? = nil
        if next == nil {
            return curr
        }
        while(curr != nil) {
            if curr!.val != prev.val && curr?.val != next?.val {
                if head == nil {
                    head = curr
                    itr = head
                } else {
                    itr?.next = curr
                    itr = itr?.next
                }
 
            }
            prev = curr!
             curr = next
             next = curr?.next
        }
        if itr != nil {
            itr?.next = nil
        }
       // printList(A)
        return head
    }
    
    
    func merge2lists(_ A: ListNode?, _ B: ListNode?) -> ListNode? {
        var first = A
        var second = B
        let merged = ListNode(value: 0)
        var head = merged
        
        while true {
            if first == nil {
                head.next = second
                break
            }
            if second == nil {
                head.next = first
                break
            }
            
            if first!.val < second!.val {
                head.next = first
                head = head.next!
                first = first?.next
            } else {
                head.next = second
                head = head.next!
                second = second?.next
            }
            
        }
        
        return merged.next
    }
    
    
    func removeTheNthNode(_ A: ListNode? , N: Int) -> ListNode? {
        var first =  A
        var second = A
        for _ in 0..<N {
            if second == nil {
                return first?.next
            }
            second = second?.next
        }
        while second?.next != nil {
            first = first?.next!
            second = second?.next!
        }
        first?.next = first?.next?.next
        return A
    }
}

var D34A  = ListNode(value: 4)
D34A.next = ListNode(value: 5)
D34A.next?.next = ListNode(value: 8)
D34A.next?.next?.next = ListNode(value: 2)
D34A.next?.next?.next?.next = ListNode(value: 3)
D34A.next?.next?.next?.next?.next = ListNode(value: 3)
D34A.next?.next?.next?.next?.next?.next = ListNode(value: 3)

var D34AB  = ListNode(value:11)
D34AB.next = ListNode(value: 15)
D34AB.next?.next = ListNode(value: 20)
//D34AB.next?.next?.next = ListNode(value: 2)
//D34AB.next?.next?.next?.next = ListNode(value: 3)
//D34AB.next?.next?.next?.next?.next = ListNode(value: 3)
//D34AB.next?.next?.next?.next?.next?.next = ListNode(value: 3)
Day34().removeTheNthNode(D34A, N: 3)
printList(D34A)






class Day33 {
    func lPalin(_ A: ListNode?) -> Int {
        var stk = [Int]()
        var cur = A
        while(cur != nil ) {
            stk.append(cur!.val)
            cur = cur!.next
        }
        cur = A
        while(cur != nil ) {
            if stk.last! != cur!.val {
                return 0
            }
            stk.popLast()
            cur = cur!.next
        }
        return 1
    }
}
var D33A  = ListNode(value: 1)
D33A.next = ListNode(value: 2)
D33A.next?.next = ListNode(value: 3)

Day33().lPalin(D33A)


















class Day32 {
    
    func ngr(_ A: inout [Int]) -> [Int] {
        var result = [Int]()
        var stk = [Int]()
        for index in stride(from: A.count-1, through: 0, by: -1) {
            if stk.isEmpty {
                result.append(-1)
                stk.first == nil
            } else if !stk.isEmpty && stk.last! <= A[index] {
                while !stk.isEmpty && stk.last! <= A[index] {
                    stk.popLast()
                }
                if stk.isEmpty {
                    result.append(-1)
                } else {
                    result.append(stk.last!)
                }
            } else {
                result.append(stk.last!)
            }
            stk.append(A[index])
        }
        result.reverse()
        return result
    }
    
    func ngl(_ A: inout [Int]) -> [Int] {
        var result = [Int]()
        var stk = [Int]()
        for index in 0 ..< A.count {
            if stk.isEmpty {
                result.append(-1)
            } else if !stk.isEmpty && stk.last! <= A[index] {
                while !stk.isEmpty && stk.last! <= A[index] {
                    stk.popLast()
                }
                if stk.isEmpty {
                    result.append(-1)
                } else {
                    result.append(stk.last!)
                }
            } else {
                result.append(stk.last!)
            }
            stk.append(A[index])
        }
        return result
    }
    
    func rainWaterTrapped(_ A: inout [Int]) -> Int {
        var result = 0
        var maxLeft = [Int]()
        var maxRight = [Int](repeating: 0, count: A.count)
        maxLeft.append(A[0])
        for index in 1..<A.count {
            maxLeft.append(max(maxLeft[index-1], A[index]))
        }
        maxRight[A.count-1] = A[A.count-1]
        for index in stride(from: A.count-2, through: 0, by: -1) {
            maxRight[index] = max(maxRight[index+1], A[index])
        }
        for index in 1..<A.count {
            result += min(maxRight[index], maxLeft[index]) - A[index]
        }
        return result
    }
    
}

var D32A = [1, 2]
Day32().rainWaterTrapped(&D32A)











class Day31 {
    
    func evalRPN(_ A: inout [String]) -> Int {
        var stk = [Int]()
        for item in A {
            if item == "+" || item == "-" || item == "*" || item == "/" {
                if stk.count < 2 {
                    return 0
                } else {
                    let first = stk.popLast()!
                    let second = stk.popLast()!
                    let result: Int
                    switch item {
                    case "+":
                       result = second + first
                    case "-":
                        result = second - first
                    case "*":
                        result = second * first
                    case "/":
                        result = second / first
                    default:
                        continue
                    }
                    print(result)
                    stk.append(result)
                }
            } else {
                stk.append(Int(item)!)
            }
            //print(stk)
        }
        return stk.popLast()!
    }
}

var D31A = [ "5", "1", "2", "+", "4", "*", "+", "3", "-" ]
Day31().evalRPN(&D31A)







class Day30 {
    func simplifyPath(A: inout String) -> String {
        var stk = [String]()
        let char: [String] = A.components(separatedBy: "/")
        var result = ""
        for item in char {
            switch item {
            case ".":
                continue
            case "/" :
                continue
            case "..":
                if !stk.isEmpty {
                    stk.popLast()
                    stk.popLast()
                }
            case "":
                continue
            default:
                stk.append("/")
                stk.append(item)
                //print(stk)
            }
        }
        if stk.isEmpty {
            return "/"
        }
        while !stk.isEmpty {
            result.append(stk.first!)
            stk.remove(at: 0)
        }
        return result
    }
    
    
    func redundantBraces(A: inout String) -> Int {
        var stk = [Character]()
        for item in A {
            print(stk)
            switch item {
            case ")":
                var opFound = false
                
                while stk.last != "(" {
                    if stk.last == "+" || stk.last == "-" || stk.last == "*" || stk.last == "/" {
                        opFound = true
                    }
                    stk.popLast()
                }
                stk.removeLast()
                if !opFound {
                    return 1
                }
            default:
                stk.append(item)
            }
        }
        return 0
    }
}


var D30A  = "(a+((b*c)+c))"
Day30().redundantBraces(A: &D30A)










class Day29 {
    
    
//    public static String firstNonRepeating(String A) {
//        Queue<Character> q = new LinkedList<Character>();
//        StringBuffer ans = new StringBuffer();
//        int[] countDict = new int[26];
//        for (int i = 0; i<A.length(); i++ ){
//            char c = A.charAt(i);
//            q.add(A.charAt(i));
//            countDict[A.charAt(i) - 'a']++;
//            while(!q.isEmpty()) {
//                if (countDict[q.peek() - 'a'] > 1 ){
//                    q.remove();
//                } else {
//                    ans.append(q.peek());
//                    break;
//                }
//            }
//            if(q.isEmpty()) {
//                ans.append('#');
//            }
//        }
//        return ans.toString();
//    }
    
    
    func ngr(A: [Int]) -> [Int] {
        var ngr = [Int]()
        var stk = [Int]()
        
        for index in stride(from: A.count-1, through: 0, by: -1) {
            if stk.count == 0 {
                ngr.append(-1)
            } else if stk.count > 0 && A[stk.last!] <= A[index] {
                while stk.count > 0 && A[stk.last!] <= A[index] {
                    stk.popLast()
                }
                if stk.count == 0 {
                    ngr.append(-1)
                } else {
                    ngr.append(stk.last!)
                }
            } else {
                ngr.append(stk.last!)
            }
            stk.append(index)
        }
        ngr = ngr.reversed()
        return ngr
    }
    
    //Input: arr[] = {1, 2, 3, 1, 4, 5, 2, 3, 6}, K = 3
    //Output: 3 3 4 5 5 5 6
    func slidingWindowMaximun(A: [Int], k: Int) -> [Int] {
        var window = [Int]()
        var ans = [Int]()
        for index in 0..<k {
            while window.count > 0 && A[window.last!] <= A[index] {
                window.popLast()
            }
            window.append(index)
        }
        print(window)
        for index in k-1..<A.count-1 {
            ans.append(A[window.first!])
            while window.count > 0 && window.first! <= index-k+1 {
                window.remove(at: 0)
            }
            while window.count > 0 && A[window.last!] <= A[index+1] {
                window.popLast()
            }
            window.append(index+1)
            print(window)
        }
        ans.append(A[window.first!])
        return ans
    }
}


var D29A = [ 1 ]//[1, 3, -1, -3, 5, 3, 6, 7]//[1, 2, 3, 1, 4, 5, 2, 3, 6]
var D29B = 1

Day29().slidingWindowMaximun(A: D29A, k: D29B)








//class Day28 {
//    func reverseString(_ A: inout String) -> String {
//        var charArray = Array(A)
//        var first = 0
//        var last = A.count-1
//        while(first < last) {
//            let temp = charArray[first]
//            charArray[first] = charArray[last]
//            charArray[last] = temp
//            first += 1
//            last -= 1
//        }
//        return String(charArray)
//    }
//

/// STACK Implementation using JAVA
//    public static ArrayList<Integer> ngr(ArrayList<Integer> a) {
//        Stack<Integer> stk = new Stack<Integer>();
//        ArrayList<Integer> ngr = new ArrayList<Integer>();
//        for(int i = a.size()-1; i >=0 ; i-- ) {
//            if(stk.size() == 0 ) {
//                ngr.add(-1);
//            } else if( stk.size() > 0 && stk.peek() <= a.get(i)) {
//                while( stk.size() > 0 && stk.peek() <= a.get(i)) {
//                    stk.pop();
//                } if (stk.size() == 0) {
//                    ngr.add(-1);
//                } else {
//                    ngr.add(stk.peek());
//                }
//            } else {
//                ngr.add(stk.peek());
//            }
//
//            stk.add(a.get(i));
//        }
//        Collections.reverse(ngr);
//        return  ngr;
//    }
//
//
//    public static ArrayList<Integer> ngl(ArrayList<Integer> a) {
//        Stack<Integer> stk = new Stack<Integer>();
//        ArrayList<Integer> ngl = new ArrayList<Integer>();
//        for(int i = 0; i < a.size() ; i++ ) {
//            if(stk.size() == 0 ) {
//                ngl.add(-1);
//            } else if( stk.size() > 0 && stk.peek() <= a.get(i)) {
//                while( stk.size() > 0 && stk.peek() <= a.get(i)) {
//                    stk.pop();
//                } if (stk.size() == 0) {
//                    ngl.add(-1);
//                } else {
//                    ngl.add(stk.peek());
//                }
//            } else {
//                ngl.add(stk.peek());
//            }
//
//            stk.add(a.get(i));
//        }
//        return  ngl;
//    }
//
//
//    public static ArrayList<Integer> nsr(ArrayList<Integer> a) {
//        Stack<Integer> stk = new Stack<Integer>();
//        ArrayList<Integer> nsr = new ArrayList<Integer>();
//        for(int i = a.size() -1; i >=0  ; i-- ) {
//            if(stk.size() == 0 ) {
//                nsr.add(-1);
//            } else if( stk.size() > 0 && stk.peek() >= a.get(i)) {
//                while( stk.size() > 0 && stk.peek() >= a.get(i)) {
//                    stk.pop();
//                } if (stk.size() == 0) {
//                    nsr.add(-1);
//                } else {
//                    nsr.add(stk.peek());
//                }
//            } else {
//                nsr.add(stk.peek());
//            }
//
//            stk.add(a.get(i));
//        }
//        Collections.reverse(nsr);
//        return  nsr;
//    }
//
//
//    public static ArrayList<Integer> nsl(ArrayList<Integer> a) {
//        Stack<Integer> stk = new Stack<Integer>();
//        ArrayList<Integer> nsl = new ArrayList<Integer>();
//        for(int i = 0; i <a.size()  ; i++ ) {
//            if(stk.size() == 0 ) {
//                nsl.add(-1);
//            } else if( stk.size() > 0 && stk.peek() >= a.get(i)) {
//                while( stk.size() > 0 && stk.peek() >= a.get(i)) {
//                    stk.pop();
//                } if (stk.size() == 0) {
//                    nsl.add(-1);
//                } else {
//                    nsl.add(stk.peek());
//                }
//            } else {
//                nsl.add(stk.peek());
//            }
//
//            stk.add(a.get(i));
//        }
//        return  nsl;
//    }
///





class Day27 {
    
     func maxArea(_ A: inout [Int]) -> Int {
        var first = 0
        var last = A.count-1
        var res = 0
        while(first < last) {
            let area = min(A[first], A[last])*(last-first)
            res = max(area, res)
            if A[first] < A[last] {
                first += 1
            } else {
                last -= 1
            }
        }
        return res
    }
}




var D27A = [1, 5, 4, 3]
Day27().maxArea(&D27A)




class Day25 {
    
    func minimize(_ A: [Int], _ B: [Int], _ C: [Int]) -> Int {
        var i = 0
        var j = 0
        var k = 0
        var res = Int.max
        while(i < A.count && j < B.count && k < C.count ) {
            let diff = max(abs(A[i]-B[j]), max(B[j]-C[k], C[k] - A[i]))
            print(diff)
            res = min(res, diff)
            if A[i] < B[j] {
                i+=1
            } else if B[j] < C[k] {
                j+=1
            } else {
                    k+=1
            }
        }
        return res
    }
}
var d25A = [1, 4, 10]
var d25B = [2, 15, 20]
var d25C = [10, 12]
Day25().minimize(d25A, d25B, d25C)






class Day24 {
    
    func maxone(_ A: inout [Int], _ B: inout Int) -> [Int] {
        var res = [Int]()
        var wL = 0
        var wR = 0
        var bestwL = 0
        var bestWindow = Int.min
        var zeroCount = 0
        while(wR < A.count) {
            if zeroCount <= B {
                if A[wR] == 0 {
                    zeroCount += 1
                }
                 wR += 1
            }
            if zeroCount > B {
                if A[wL] == 0 {
                    zeroCount -= 1
                }
                 wL += 1
            }
            if (wR - wL) > bestWindow && zeroCount <= B {
                bestWindow = wR - wL
                print(bestWindow)
                bestwL = wL
            }
        }
        for i in 0..<bestWindow {
            res.append(i+bestwL)
        }
        return res
    }
}

var D24A = [1, 1, 0, 1, 1, 0, 0, 1, 1, 1 ]
var D24B = 1
Day24().maxone(&D24A, &D24B)









func threePointer(_ A: inout [Int]){
    var start = 0
    var middle = 0
    var last = A.count-1
    while(middle <= last) {
        if A[middle] == 0 {
            let temp = A[middle]
            A[middle] = A[start]
            A[start] = temp
            start+=1
            middle += 1
        } else if A[middle] == 2 {
            let temp = A[middle]
            A[middle] = A[last]
            A[last] = temp
            last -= 1
        } else {
            middle += 1
        }
        
    }
}





class Day23 {
    
    func diffPossible(_ A: inout [Int], _ B: inout Int) -> Int {
        var first = 0
        var second = 1
        while(first < A.count && second < A.count) {
            let diff = A[second] - A[first]
            if diff == B && second != first {
                return 1
            } else if diff > B {
                first += 1
            } else {
                second += 1
            }
        }
        return 0
    }
    
    
    func removeDuplicate(_ A: inout [Int]) {
        var first = 0
        var second = 1
        while(first < A.count && second < A.count) {
            if A[first] == A[second] {
                A.remove(at: second)
            } else {
                first += 1
                second += 1
            }
        }
    }
}
var D23A: [Int] = [ 5000, 5000, 5000 ]
var D23K = 4
Day23().removeDuplicate(&D23A)


Day23().diffPossible(&D23A, &D23K)










class Day22 {
    
    
    func threeSum(_ A: inout [Int]) -> [[Int]] {
        A = A.sorted()
        var result = [[Int]]()
        if A.count < 3 {
            return result
        }
        for first in 0...A.count-2 {
            var second = first + 1
            var last = A.count-1
            while(second < last) {
                let sum  = A[first] + A[second] + A[last]
                if sum == 0 {
                    let row = [A[first], A[second], A[last]]
                    //print(row)
                    var contains = result.contains { element in
                        if element != row {
                            return false
                        } else {
                            return true
                        }
                    }
                    if !contains {
                        result.append(row)
                    }
                    second += 1
                    last -= 1
                } else if sum > 0 {
                    last -= 1
                } else {
                    second += 1
                }
            }
        }
        print(result)
        return result
     }
    
    
    
    
    
    
    
    func nTriang(_ A: inout [Int]) -> Int {
        var result = 0
        if A.count < 3 {
            return result
        }
        A = A.sorted()
        
        for last in stride(from: A.count-1, through: 2, by: -1) {
            var first = 0
            var second = last-1
            while (first < second) {
                if  A[first] + A[second] > A[last] {
                    print(result)
                    result += (second - first) % 100000007
                    second -= 1
                } else {
                 first += 1
                }
            }
        }
        print(result)
        return result
    }
}


var D22A = [ 4, 6, 13, 16, 20, 3, 1, 12 ]//[ 1, -4, 0, 0, 5, -5, 1, 0, -2, 4, -4, 1, -1, -4, 3, 4, -1, -1, -3 ]

Day22().nTriang(&D22A)

func product(_ A: inout [Int]) -> [Int] {
    var product = [Int]()
    product.append(1)
    
    for index in 1..<A.count {
        let lProduct = A[index-1]*product[index-1]
        product.append(lProduct)
    }
    var temp = 1
    
    for index in stride(from: A.count-1, through: 0, by: -1) {
        let rProduct = temp*product[index]
        product[index] = rProduct
        temp = temp * A[index]
    }
    return product
}

var Z = [1,2,3,4]
product(&Z)















class Day21 {
    
    func intersect(_ A: [Int], _ B: [Int]) -> [Int] {
        var first = 0
        var second = 0
        var result = [Int]()
        while(first < A.count && second<B.count) {
            if A[first] == B[second] {
                result.append(A[first])
                first += 1
                second += 1
            } else if A[first] > B[second] {
                second += 1
            } else {
                first += 1
            }
        }
        return result
    }
    
    
    
    
    func threeSumClosest(_ A: inout [Int], _ B: inout Int) -> Int {
        var second  = 1
        var last =  A.count-1
        var result = A[0] + A[second] + A[last]
        A = A.sorted()
        for first in 0 ..< A.count-2 {
           second = first + 1
            last  = A.count-1
            while(second < last) {
                let sum = A[first] + A[second] + A[last]
                if abs(B-sum) < abs(B-result) {
                    result = sum
                }
                if sum > B {
                    last -= 1
                } else {
                    second += 1
                }
            }
        }
      return result
    }
}


var D21A2 = [-1, 2, 1, -4]//[ -10, -10, -10 ]
var D21B2 =  1
Day21().threeSumClosest(&D21A2, &D21B2)


var D21A = [1, 2, 3, 3, 4, 5, 6]
var D21B =  [3, 5]
Day21().intersect(D21A, D21B)


















class Day20 {
    
    func givenDiff(_ A: inout [Int], _ B: inout Int) -> Int {
        A = A.sorted()
        var start = 0
        var end = 1
        while(start < A.count && end < A.count-1) {
            let diff = A[end] - A[start]
            if diff == B && start != end {
                return 1
            } else if diff > B {
                start += 1
            } else  {
                end += 1
            }
        }
        return 0
    }
}

var D20A = [ -533, -666, -500, 169, 724, 478, 358, -38, -536, 705, -855, 281, -173, 961, -509, -5, 942, -173, 436, -609, -396, 902, -847, -708, -618, 421, -284, 718, 895, 447, 726, -229, 538, 869, 912, 667, -701, 35, 894, -297, 811, 322 ]
var D20B = 369

Day20().givenDiff(&D20A, &D20B)












class Day19 {
    func search(_ A: [Int], _ B: inout Int) -> Int {
        let pivot = findPivot(A: A)
        print(pivot)
        let left = BNSearch(A: A, low: 0, high: pivot, key: B)
        if left != -1 {
            return left
        } else {
            return BNSearch(A: A, low: pivot+1, high: A.count-1, key: B)
        }
    }
    
    
    func findPivot(A: [Int]) -> Int {
        var low = 0
        var high = A.count-1
        
        while(low <= high) {
            
            let mid = low + ((high-low)/2)
            print(mid)
            if mid < high && A[mid+1] < A[mid]{
                return mid
                
            }
            if low < mid && A[mid] < A[mid-1] {
                return mid-1
            }
            else if A[mid] > A[low] {
                low = mid+1
            } else {
                high = mid-1
            }
        }
        return -1
    }
    
    func BNSearch(A: [Int], low: Int, high: Int, key: Int) -> Int {
        var low = low
        var high = high
        
        while(low <= high) {
            let mid = low + ((high-low)/2)
            if A[mid] == key {
            return mid
            } else if A[mid] < key {
                low = mid+1
            } else {
                high = mid-1
            }
        }
        
        return -1
    }
}

var D19A = [ 101, 103, 106, 109, 158, 164, 182, 187, 202, 205, 2, 3, 32, 57, 69, 74, 81, 99, 100 ]
var D19B = 202

Day19().search(D19A, &D19B)





















class Day18 {
    func searchMatrix1(_ A: inout [[Int]], _ B: inout Int) -> Int {
        var tem = [Int]()
        
        for i in 0..<A.count {
            for j in 0..<A[0].count {
                tem.append(A[i][j])
            }
        }
        let ans = search(A: tem, B: B)
        return ans
    }
    
    
    func search(A: [Int], B: Int) -> Int {
        if A.count < 1 {
            return 0
        }
        var low = 0
        var high = A.count-1
        while low <= high {
            let mid = low + ((high-low)/2)
            if A[mid] == B {
                return 1
            } else if A[mid] < B {
                low = mid + 1
            } else {
                high = mid-1
            }
        }
        return 0
    }
    
    
    //o(n)
    //=================================
    
    func searchMatrix(_ A: inout [[Int]], _ B: inout Int) -> Int {
        var row = 0
        var col = A[0].count-1
        
        while (row < A.count && col >= 0 ) {
            let element = A[row][col]
            if element == B {
                return 1
            } else if element > B {
                col -= 1
            } else {
                row += 1
            }
        }
       return 0
    }
    
    
    func searchRange(_ A: [Int], _ B: inout Int) -> [Int] {
        var ans  = [-1, -1]
        var low = 0
        var high = A.count-1
        
        while low <= high {
            let mid = low + ((high-low)/2)
            if A[mid] == B {
                ans[0] = mid
                if mid-1 >= 0 && A[mid-1] != B {
                    break
                } else {
                    high = mid-1
                }
                
            } else if A[mid] < B {
                low = mid + 1
            } else {
                high = mid-1
            }
        }
        low = 0
        high = A.count-1
        while low <= high {
            let mid = low + ((high-low)/2)
            if A[mid] == B {
                ans[1] = mid
                if mid+1 <= A.count-1 && A[mid+1] != B {
                    break
                } else {
                    low = mid+1
                }
                
            } else if A[mid] < B {
                low = mid + 1
            } else {
                high = mid-1
            }
        }
        return ans
    }
}



var D18A =  [5]


var D18B = 5

Day18().searchRange(D18A, &D18B)
//Day18().searchMatrix(&D18A, &D18B)













class Day17 {
    
    func paint(_ A: inout Int, _ B: inout Int, _ C: inout [Int]) -> Int {
        var sum = 0
        if A < 1 {
            return -1
        }
        var maxValue = Int.min
        for item in C {
            sum = sum + item*B
            maxValue = max(maxValue, item*B)
        }
        var low = 0
        var high = sum
        while low < high {
            let midValue = low + ((high-low)/2)
            if isValidInput(threshold: midValue, A: C, partitions: A) {
                high = midValue
            } else {
                low = midValue+1
            }
        }
        return (low*B) % 10000003
    }
    
    
    
    func books(_ A: inout [Int], _ B: inout Int) -> Int {
        if B > A.count || B < 1 {
            return -1
        }
        
        var sum = 0
        var maxValue = Int.min
        for item in A {
            sum = sum + item
            maxValue = max(maxValue, item)
        }
        var low = 0
        var high = sum
        while low < high {
            let midValue = low + ((high-low)/2)
            print(midValue)
            if isValidInput(threshold: midValue, A: A, partitions: B) {
                high = midValue
            } else {
                low = midValue+1
            }
        }
        return high
    }
    
    func isValidInput(threshold: Int, A: [Int], partitions: Int) ->  Bool {
        var totalCount = 1
        var sum = 0
        for index in 0 ..< A.count {
            if A[index] > threshold { return false }
            sum = sum + A[index]
            if sum > threshold {
                sum = A[index]
                totalCount += 1
            }
            print(totalCount)
            if totalCount > partitions {
                return false
            }
        }
        return true
    }
}

var D172A = [ 12, 34, 67, 90 ]//[5, 17, 100, 11]//[12, 34, 67, 90]//[ 12, 34, 67, 90 ]
var D172B = 2
Day17().books(&D172A, &D172B)




var D17A = 1
var D17B = 10
var D17C = [1]//[ 640, 435, 647, 352, 8, 90, 960, 329, 859 ]
Day17().paint(&D17A, &D17B, &D17C)








class Day16 {
    func findMatrixMedian(_ A: inout [[Int]]) -> Int {
        let medianIndex = ((A.count*A[0].count + 1)/2) - 1
        var output = [Int]()
        for i in 0..<A.count {
            for j in 0..<A[0].count {
                output.append(A[i][j])
            }
        }
        output = output.sorted()
        let ans = output[medianIndex]
        return ans
    }
    
    
    func sqrt(_ A: inout Int) -> Int {
        if A == 0 || A == 1 {
            return A
        }
        var low: Int = 1
        var high: Int = A
        //var ans = 0
        while low <= high {
            let mid: Int = low + ((high - low)/2)
            let square = mid*mid
            if square == A {
                return mid
            } else if square > A {
                high = mid-1
            } else {
                //ans = mid
                low = mid+1
            }
        }
        return high
    }
    
}

var D16B = 11
Day16().sqrt(&D16B)

var D16A = [   [1, 3, 5],
[2, 6, 9],
[3, 6, 9]   ]
////[
//  [1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3]
//]
Day16().findMatrixMedian(&D16A)

class Day13 {
    
    func firstMissingPositive(_ A: inout [Int]) -> Int {
        A = A.sorted()
        var value = 1
        for index in 0...A.count-1 {
            if A[index] >= 1 {
                if A[index] == value {
                    value += 1
                } else {
                    return value
                }
            }
        }
        return value
    }
    
    
    
    func firstMissingPositive2(_ A: inout [Int]) -> Int {
        
        A = segregate(&A)
        for index in 0..<A.count {
            let x = abs(A[index])
            if x-1 < A.count && A[x-1] > 0 {
                A[x-1] = -A[x-1]
            }
        }
        
        for index in 0..<A.count {
            if  A[index] > 0 {
                return index + 1
            }
        }
        return A.count+1
    }
    
    func segregate(_ A: inout [Int]) -> [Int] {
        var swapIndex = 0
        for index in 0...A.count-1 {
            if A[index] <= 0 {
                let temp = A[index]
                A[index] = A[swapIndex]
                A[swapIndex] = temp
                swapIndex += 1
            }
        }
        var B = [Int]()
        for index in swapIndex..<A.count {
            B.append(A[index])
        }
        return B
    }
    
    
    
    func repeatedNumber(_ A: [Int]) -> [Int] {
        var B = A
        var result = [Int]()
        for index in 0..<B.count {
            print(B)
            if B[abs(B[index])-1] < 0 {
                result.append(abs(B[index]))
            } else {
                B[abs(B[index])-1] = -B[abs(B[index])-1]
            }
        }
        print(B)
        for index in 0...A.count-1 {
            if B[index] > 0 {
                result.append(index+1)
            }
        }
        return result
    }
}

var D13B = [3, 1, 2, 5, 3]
Day13().repeatedNumber(D13B)

var D13A = [1,2,0]//[ 417, 929, 845, 462, 675, 175, 73, 867, 14, 201, 777, 407, 80, 882, 785, 563, 209, 261, 776, 362, 730, 74, 649, 465, 353, 801, 503, 154, 998, 286, 520, 692, 68, 805, 835, 210, 819, 341, 564, 215, 984, 643, 381, 793, 726, 213, 866, 706, 97, 538, 308, 797, 883, 59, 328, 743, 694, 607, 729, 821, 32, 672, 130, 13, 76, 724, 384, 444, 884, 192, 917, 75, 551, 96, 418, 840, 235, 433, 290, 954, 549, 950, 21, 711, 781, 132, 296, 44, 439, 164, 401, 505, 923, 136, 317, 548, 787, 224, 23, 185, 6, 350, 822, 457, 489, 133, 31, 830, 386, 671, 999, 255, 222, 944, 952, 637, 523, 494, 916, 95, 734, 908, 90, 541, 470, 941, 876, 264, 880, 761, 535, 738, 128, 772, 39, 553, 656, 603, 868, 292, 117, 966, 259, 619, 836, 818, 493, 592, 380, 500, 599, 839, 268, 67, 591, 126, 773, 635, 800, 842, 536, 668, 896, 260, 664, 506, 280, 435, 618, 398, 533, 647, 373, 713, 745, 478, 129, 844, 640, 886, 972, 62, 636, 79, 600, 263, 52, 719, 665, 376, 351, 623, 276, 66, 316, 813, 663, 831, 160, 237, 567, 928, 543, 508, 638, 487, 234, 997, 307, 480, 620, 890, 216, 147, 271, 989, 872, 994, 488, 291, 331, 8, 769, 481, 924, 166, 89, 824, -4, 590, 416, 17, 814, 728, 18, 673, 662, 410, 727, 667, 631, 660, 625, 683, 33, 436, 930, 91, 141, 948, 138, 113, 253, 56, 432, 744, 302, 211, 262, 968, 945, 396, 240, 594, 684, 958, 343, 879, 155, 395, 288, 550, 482, 557, 826, 598, 795, 914, 892, 690, 964, 981, 150, 179, 515, 205, 265, 823, 799, 190, 236, 24, 498, 229, 420, 753, 936, 191, 366, 935, 434, 311, 920, 167, 817, 220, 219, 741, -2, 674, 330, 909, 162, 443, 412, 974, 294, 864, 971, 760, 225, 681, 689, 608, 931, 427, 687, 466, 894, 303, 390, 242, 339, 252, 20, 218, 499, 232, 184, 490, 4, 957, 597, 477, 354, 677, 691, 25, 580, 897, 542, 186, 359, 346, 409, 655, 979, 853, 411, 344, 358, 559, 765, 383, 484, 181, 82, 514, 582, 593, 77, 228, 921, 348, 453, 274, 449, 106, 657, 783, 782, 811, 333, 305, 784, 581, 746, 858, 249, 479, 652, 270, 429, 614, 903, 102, 378, 575, 119, 196, 12, 990, 356, 277, 169, 70, 518, 282, 676, 137, 622, 616, 357, 913, 161, 3, 589, 327 ]//[-8, -7, -6]//[3,4,-1,1] //[1,2,0]
Day13().firstMissingPositive2(&D13A)

class Day12 {
    
    func factorial(_ A: inout Int) -> String {
        if A == 0 || A == 1 {
            return "1"
        }
        
        var result = fact(A: A)

        return String(result)
    }
    
    func fact(A: Int) -> Int {
        if A == 0 ||  A == 1 {
            return 1
        }
        
        return A*fact(A: A-1)
    }
    
    
    
    func nextPermutation(_ A: inout [Int]) -> [Int] {
        var firstSwapElement = -1
        for index in stride(from: A.count-1, through: 1, by: -1) {
            if A[index - 1] < A[index] {
                firstSwapElement = index-1
                //print(firstSwapElement)
                break
            }
        }
        if firstSwapElement == -1 {
            return A.sorted()
        }
        
        var secondSwapElement = -1
        for index in firstSwapElement+1..<A.count {
            if A[index] > A[firstSwapElement] {
                if secondSwapElement == -1 {
                    secondSwapElement = index
                }
                if A[index] < A[secondSwapElement] {
                    secondSwapElement = index
                }
                //print(secondSwapElement)
            }
        }
        
        let temp = A[secondSwapElement]
        A[secondSwapElement] = A[firstSwapElement]
        A[firstSwapElement] = temp
        var B = [Int]()
        for _ in firstSwapElement+1..<A.count {
            B.append(A[firstSwapElement+1])
            A.remove(at: firstSwapElement+1)
        }
        B = B.sorted()
        A.append(contentsOf: B)
        //print(A)
        return A
    }
}
var D12BB = 8
Day12().factorial(&D12BB)

var D12A = [1, 2, 3]//[ 444, 994, 508, 72, 125, 299, 181, 238, 354, 223, 691, 249, 838, 890, 758, 675, 424, 199, 201, 788, 609, 582, 979, 259, 901, 371, 766, 759, 983, 728, 220, 16, 158, 822, 515, 488, 846, 321, 908, 469, 84, 460, 961, 285, 417, 142, 952, 626, 916, 247, 116, 975, 202, 734, 128, 312, 499, 274, 213, 208, 472, 265, 315, 335, 205, 784, 708, 681, 160, 448, 365, 165, 190, 693, 606, 226, 351, 241, 526, 311, 164, 98, 422, 363, 103, 747, 507, 669, 153, 856, 701, 319, 695, 52 ]//[20, 50, 113]//[3, 2, 1]//[1, 2, 3]
Day12().nextPermutation(&D12A)







func getPrefixArray(pattern: String) -> [Int] {
    var prefixArray = [Int]()
    prefixArray.append(.zero)
    var length = 0
    let patternArray = Array(pattern)
    var index = 1
    while index < pattern.count {
        if patternArray[index] == patternArray[length] {
            length += 1
            prefixArray.append(length)
        } else {
            if length != 0 {
                length = prefixArray[length-1]
                index -= 1
                                print(prefixArray)
            } else {
                prefixArray.append(0)
                print(prefixArray)
            }
        }
    }
    return prefixArray
}

func kmp(textBody: String, pattern: String) -> [Int] {
    var ranges = [Int]()
    let textSize = textBody.count
    let patternSize = pattern.count
    let prefixArray = getPrefixArray(pattern: pattern)
    let textArray = Array(textBody)
    let patternArray = Array(pattern)
    var iteratorInText = 0
    var iteratorInPattern = 0
    while(iteratorInText < textSize) {
        if textArray[iteratorInText] == patternArray [iteratorInPattern] {
            iteratorInText += 1
            iteratorInPattern += 1
        }
        if iteratorInPattern == patternSize {
            ranges.append(iteratorInText-iteratorInPattern)
            iteratorInPattern = prefixArray[iteratorInPattern-1]
        } else if iteratorInText < textSize && patternArray[iteratorInPattern] != textArray[iteratorInText] {
            if iteratorInPattern != 0 {
                iteratorInPattern = prefixArray[iteratorInPattern-1]
            } else {
                iteratorInText += 1
            }
        }
    }
    return ranges
}

var TA = "AAAABAAAAABBBAAAAB"
var PA = "AAAB"
kmp(textBody: TA, pattern: PA)



String(10) + String(99)
class Day11 {
    func diagonal(_ A: inout [[Int]]) -> [[Int]] {
        var result = [[Int]]()
        var col = 0
        var row = 0
        while col < A[0].count && row < A.count {
            let prevCol = col
            let prevRow = row
            var rowElement = [Int]()
            while col >= 0 && row < A.count {
                //print(row , col)
                rowElement.append(A[row][col])
                col -= 1
                row += 1
            }
            result.append(rowElement)
            if prevCol + 1 == A[0].count {
                col = A[0].count - 1
                row = prevRow + 1
                print(row , col)
            } else {
                col = prevCol + 1
                row = 0
                print(row , col)
            }
        }

        return result
    }
    
    func largestNumber(_ A: [Int]) -> String {
        var result = ""
        var temp = [String]()
        for item in A {
            temp.append(String(item))
        }
        temp.sort {
            let XY =  $0 + $1
            let YX = $1 + $0
            return XY > YX
        }
        var zeroCount = 0
        for item in temp {
            if item == "0" {
                zeroCount += 1
            }
            result.append(item)
        }
        if zeroCount == A.count {
        return "0"
        }
        return result
    }
    
}


var D11A = [[1, 2, 3],
         [4, 5, 6],
         [7, 8, 9]
]

var D11B = [ 0, 0, 0, 0, 0 ]//[3, 30, 34, 5, 9]
Day11().largestNumber(D11B)







class Day10 {
    func pascalTriangle(_ A: inout Int) -> [[Int]] {
        var triangle = [[Int]]()
        
        for i in 0..<A {
            var row = [Int]()
            for _ in 0..<i+1 {
                row.append(-1)
            }
            triangle.append(row)
        }
        //print(triangle)
        for row in 0..<A {
            for col in 0...row {
                if col == 0 || col == row {
                    triangle[row][col] = 1
                } else {
                    triangle[row][col] = triangle[row-1][col] + triangle[row-1][col-1]
                }
            }
           // print(triangle)
        }
        return triangle
    }
    
    
    func pascalTriangleGetRow(_ A: inout Int) -> [Int] {
        var triangle = [Int]()
        
        for _ in 0...A {
            triangle.append(-1)
        }
        //print(triangle)
        for row in 0...A {
        let temp = triangle
            for col in 0...row {
                if col == 0 || col == row {
                    triangle[col] = 1
                } else {
                    triangle[col] = temp[col] + temp[col-1]
                }
            }
            //print(triangle)
        }
        return triangle
    }
}

var A = 2
Day10().pascalTriangleGetRow(&A)















class Day9 {
    func maximumGap(_ A: [Int]) -> Int {
        var maxDif = -1
        var minFromLeft = [Int]()
        var maxFromRight = Array(repeating: -1, count: A.count)
        minFromLeft.append(A[0])
        for index in 1..<A.count {
            let value = min(minFromLeft[index-1], A[index])
            minFromLeft.append(value)
        }
        print(minFromLeft)
        maxFromRight[A.count-1] = A[A.count-1]
        for index in stride(from: A.count-2, through: 0, by: -1) {
            let value = max(maxFromRight[index+1], A[index])
            maxFromRight[index] = value
        }
        print(maxFromRight)
        var i = 0
        var j = 0
        while i < A.count &&  j < A.count {
            if minFromLeft[i] <= maxFromRight[j] {
                print(maxDif)
                maxDif = max(maxDif, j-i)
                j = j+1
            } else {
                i += 1
            }
        }
        return maxDif
    }
    
    func generateMatrix(_ A: inout Int) -> [[Int]] {
        var matrix = [[Int]]()
        var row = A
        var col = A
        for _ in 0..<A {
            var row = [Int]()
            for _ in 0..<A {
                row.append(-1)
            }
            matrix.append(row)
        }
        var r = 0
        var c = 0
        var count = 1
        while (r < row && c < col) {
            for index in c..<col {
                matrix[r][index] = count
                count += 1
            }
            r = r+1
            for index in r..<row {
                matrix[index][col-1] = count
                count += 1
            }
            col = col-1
            if r < row {
            for index in stride(from: col-1, through: 0, by: -1) {
                matrix[row-1][index] = count
                count += 1
                }
                row -= 1
            }
            if c < col {
            for index in stride(from: row-1, through: r, by: -1) {
                matrix[index][c] = count
                count += 1
            }
                c += 1
        }
        }
        return matrix
     }
    
    
}

var D9A = [3, 5, 4, 2]
var D9B = 4
Day9().generateMatrix(&D9B)

class Day8 {
    func subUnsort(_ A: inout [Int]) -> [Int] {
        var ans = [Int]()
        ans.append(Int.min)
        ans.append(Int.max)
        for i in 0 ..< A.count-1 {
            for j in i+1 ..< A.count {
                if A[j] < A[i] {
                    let prev  = ans[0]
                    ans[0] = prev < j ? j : prev
                }
            }
        }
        for i in stride(from: A.count - 1, through: 1, by: -1) {
            for j in stride(from: i - 1, through: 0, by: -1) {
                if A[j] > A[i] {
                    let prev  = ans[1]
                    ans[1] = j < prev ? j : prev
                }
            }
        }
        if ans[0] == Int.min {
            return [-1]
        }
        ans = ans.reversed()
        return ans
    }

}
var D8A = [ 4, 15, 4, 4, 15, 18, 20 ]//[ 1, 1, 2, 3, 3, 4, 8, 9, 11, 9, 11, 12, 12, 11, 9, 14, 19, 20, 20 ]//[ 1, 1, 10, 10, 15, 10, 15, 10, 10, 15, 10, 15 ]//[ 1, 1, 2, 3, 3, 4, 8, 9, 11, 9, 11, 12, 12, 11, 9, 14, 19, 20, 20 ]//[ 4, 15, 4, 4, 15, 18, 20 ]//[1, 2, 3, 4, 5]//[ 1, 3, 2, 4, 5 ]
Day8().subUnsort(&D8A)













class Solution {
    func solve(_ A: inout [Int]) -> Int {
        for i in 0..<A.count {
            var times = 0
            for j in 0..<A.count {
                if i == j {
                    continue
                } else {
                    if A[j] > A[i] {
                        times += 1
                    }
                }
            }
            if A[i] == times {
                return 1
            }
    
        }
        return -1
    }
    
    func solve2(_ A: inout [Int]) -> Int {
        var B = A.sorted()
        for i in 0..<A.count-1 {
            if B[i] == B[i+1] {
                continue
            }
            if B[i] == (B.count - 1 - i) {
                print("B is \(B[i])")
                print("B is \(B.count - 1 - i)")
                return 1
            }
        }
        
        
        if (B[B.count-1] == 0) {
            return 1
        }
        
        
        return -1
    }
    
    
    func wave(_ A: inout [Int]) -> [Int] {
        if A.count < 2 {
            return A
        }

       // A = A.sorted()
        for index in stride(from: 1, through: A.count - 1, by: 2) {
            if A[index] > A[index-1] {
                let temp = A[index-1]
                A[index-1] = A[index]
                A[index] = temp
            }
            if index + 1 > A.count - 1 {
                continue
            }
            if A[index] > A[index+1] {
                let temp = A[index+1]
                A[index+1] = A[index]
                A[index] = temp
            }
        }
        return A
    }
}


var sA = [ 5, 1, 3, 2, 4 ]//[1, 2, 3, 4] //[ -4, 7, 5, 3, 5, -4, 2, -1, -9, -8, -3, 0, 9, -7, -4, -10, -4, 2, 6, 1, -2, -3, -1, -8, 0, -8, -7, -3, 5, -1, -8, -8, 8, -1, -3, 3, 6, 1, -8, -1, 3, -9, 9, -6, 7, 8, -6, 5, 0, 3, -4, 1, -10, 6, 3, -8, 0, 6, -9, -5, -5, -6, -3, 6, -5, -4, -1, 3, 7, -6, 5, -8, -5, 4, -3, 4, -6, -7, 0, -3, -2, 6, 8, -2, -6, -7, 1, 4, 9, 2, -10, 6, -2, 9, 2, -4, -4, 4, 9, 5, 0, 4, 8, -3, -9, 7, -8, 7, 2, 2, 6, -9, -10, -4, -9, -5, -1, -6, 9, -10, -1, 1, 7, 7, 1, -9, 5, -1, -3, -3, 6, 7, 3, -4, -5, -4, -7, 9, -6, -2, 1, 2, -1, -7, 9, 0, -2, -2, 5, -10, -1, 6, -7, 8, -5, -4, 1, -9, 5, 9, -2, -6, -2, -9, 0, 3, -10, 4, -6, -6, 4, -3, 6, -7, 1, -3, -5, 9, 6, 2, 1, 7, -2, 5 ] //[1, 1, 3, 3] //[3, 2, 1, 3]
//1 2 3 3
Solution().wave(&sA)









class Solution9 {
    
    func maximumGap(_ A: [Int]) -> Int {
        var max = Int.min
        if A.count < 2 {
            return 0
        }
        let temp = A.sorted()
        for index in 0..<temp.count-1 {
            let diff = temp[index+1] - temp[index]
            max = diff > max ? diff : max
        }
        return max
    }
}












class Solution8 {
    func solve(_ A: inout [String]) -> Int {
        var ans = 0
        var temp = [Float]()
        for i in 0..<A.count {
            temp.append(Float(A[i]) ?? 0)
        }
        print(temp)
        if temp.count < 3 {
            return ans
        }
        var a = temp[0]
        var b = temp[1]
        var c = temp[2]
        for index in 3..<temp.count {
            if a+b+c > 1 && a+b+c < 2 {
                return 1
            } else if a+b+c > 2 {
                if (a>b && a>c) {
                    a = temp[index]
                }
                else if (b>a && b>c) {
                    b = temp[index]
                }
                else if (c>a && c>b) {
                    c = temp[index]
                }
            } else {
                if (a<b && a<c) {
                    a = temp[index]
                }
                else if (b<a && b<c) {
                    b = temp[index]
                }
                else if (c<a && c<b) {
                    c = temp[index]
                }
            }
        }
        if a+b+c > 1 && a+b+c < 2 {
            return 1
        } else {
            return 0
        }
    }
}

var s8A = [ "2.673662", "2.419159", "0.573816", "2.454376", "0.403605", "2.503658", "0.806191" ]
Solution8().solve(&s8A)

class Solution7 {
    func repeatedNumber1(_ A: [Int]) -> Int {
        var ans = [Int]()
        for item in A {
            if ans.contains(item) {
                return item
            } else {
                ans.append(item)
            }
        }
        return -1
    }
    
    func repeatedNumber2(_ A: [Int]) -> Int {
        var ans = A
        for index in 0..<A.count {
            if ans[abs(ans[index])] < 0 {
                return abs(ans[index])
            } else {
                ans[ans[index]] = -ans[ans[index]]
            }
        }
        return -1
    }
}
let S7A = [3, 4, 1, 4, 1]
Solution7().repeatedNumber2(S7A)


class Solution6 {
    
    func solve(_ A: inout Int, _ B: inout [Int]) -> Int {
        var ans = 0
        var sum = 0
        for item in B {
            sum = sum + item
        }
        if sum % 3 != 0 {
            return 0
        }
        let partitionValue = sum/3
        var suffix = [Int]()
        var value = 0
        for index in stride(from: B.count - 1, through: 0, by: -1) {
            value = value + B[index]
            let flag = value == partitionValue ? 1 : 0
            suffix.append(flag)
        }
        suffix.reverse()
        print(suffix)
        value = 0
        var prefix = [Int]()
        for index in stride(from: 0, through: B.count - 1, by: 1) {
            value = value + B[index]
            let flag = value == partitionValue ? 1 : 0
            prefix.append(flag)
        }
        print(prefix)
        for i in 0..<prefix.count {
            for j in stride(from: B.count - 1, through: 0, by: -1) {
                if prefix[i] == 1 && suffix [j] == 1 {
                    if j > i {
                        var sum = 0
                        for k in i+1..<j {
                            sum = sum + B[k]
                        }
                        ans = sum == partitionValue ? ans+1 : ans
                    }
                }
            }
        }
        return ans
    }
    
    
    func flip(_ A: inout String) -> [Int] {
        var res = [Int]()
        var l = -1
        var r = -1
        var start = 0
        var max = 0
        var count = 0
        let characters = Array(A)
        for index in 0..<characters.count {
            if characters[index] == "0" {
                count += 1
            }
            if characters[index] == "1" {
                count -= 1
            }
            if count > max {
                max = count
                l = start+1
                r = index+1
            }
            if count < 0 {
                count = 0
                start = index+1
            }
            
        }
        if l == -1 && r == -1 {
            return res
        } else {
            res.append(l)
            res.append(r)
        }
        return res
    }
}

//var s6A = 4
//var s6B = [0, 1, -1, 0]
var s6I = "010"
Solution6().flip(&s6I)

class Solution5 {
    /// O(n^2)
    func maxArr(_ A: inout [Int]) -> Int {
        var max  = A.count > 1 ? Int.min : 0
        for i in 0..<A.count-1 {
            for j in i+1..<A.count {
                let value  = abs(i-j) + abs(A[i] - A[j])
                max = value > max ? value : max
            }
        }
        return max
    }
    
    /// O(n)
    func maxArrN(_ A: inout [Int]) -> Int {
        var max1 = Int.min
        var max2 = Int.min
        var min1 = Int.max
        var min2 = Int.max
        
        for index in 0..<A.count {
            max1 = max(max1, A[index] + index)
            min1 = min(min1, A[index] + index)
            max2 = max(max2, A[index] - index)
            min2 = min(min2, A[index] - index)
        }
        return max(max1-min1, max2-min2)
    }
    
    
    
}
var S5A = [1, 3, -1]
Solution5().maxArrN(&S5A)


class Solution4 {
    func maxSubArray(_ A: [Int]) -> Int {
        var currentSum = 0
        var maxSum = Int.min
        for item in A {
            currentSum = currentSum + item
            if currentSum > maxSum {
                maxSum = currentSum
            }
            if currentSum < 0 {
                currentSum = 0
            }
        }
        return maxSum
    }
}

let S4A = [ -163, -20 ]

Solution4().maxSubArray(S4A)




class Solution1 {
   
    func coverPoints(_ A: inout [Int], _ B: inout [Int]) -> Int {
        var steps = 0
        for i in 0...A.count - 2 {
            let distance = maxDistance(ax: A[i], bx: A[i+1], ay: B[i], by: B[i+1])
            steps += distance
        }
        return steps
    }

    func maxDistance(ax: Int, bx:Int, ay: Int, by: Int) -> Int {
        let xDistance = abs(bx - ax)
        let yDistance = abs(by - ay)
        return max(xDistance, yDistance)
}
}
//var A = [ -7, -13 ]
var B = [ 1, -5 ]

//Solution().coverPoints(&A, &B)


//class Solution2 {
//    func plusOne(_ A: inout [Int]) -> [Int] {
//        var multiplier = 1
//        var number = 0
//        for index in A.count-1...0 {
//            let temp = A[index]
//            number += temp*multiplier
//            multiplier  = multiplier*10
//        }
//        number = number+1
//        var index = 0
//        while number > 0 {
//            A[index] = number%10
//            number = number/10
//            index += 1
//        }
//
//        return A.reversed()
//    }
//}
//
//var C = [ 2, 5, 6, 8, 6, 1, 2, 4, 5 ]
//Solution2().plusOne(&C)


class Solution3 {
    func plusOne(_ A: inout [Int]) -> [Int] {
        var carry = 0
        var ans = [Int]()
        let number = A[A.count-1] + 1
        ans.append(number%10)
        carry = number/10
        for index in stride(from: A.count - 2, through: 0, by: -1) {
            if carry == 1 {
                let number = A[index] + 1
                ans.append( number % 10)
                carry = number/10
            } else {
                ans.append(A[index]%10)
            }
        }
        if carry != 0 {
             ans.append((A[0]+carry)/10)
        }
        while (ans.last == 0) {
            ans.remove(at: ans.count-1)
        }
        return ans.reversed()
    }
}

var D = [  0, 0, 4, 4, 6, 0, 9, 6, 5, 1 ]
Solution3().plusOne(&D)

56%19
func rotate(a: [Int], b: Int) {
    var c = b % a.count
    var result = [Int]()
    for index in 0..<a.count {
        result.append(a[(index+b)%a.count])
    }
    while(b > 0) {
        result.append(a[b])
        c = c-1
    }
}

rotate(a: [ 14, 5, 14, 34, 42, 63, 17, 25, 39, 61, 97, 55, 33, 96, 62, 32, 98, 77, 35 ], b: 56)


func inPlaceMerge(A: inout [Int], B: inout [Int]) -> [Int] {
    if A.count >= B.count {
        return merge(A: &A, B: &B)
    } else {
        return merge(A: &B, B: &A)
    }
}

func merge(A: inout [Int], B: inout [Int]) -> [Int]{
    var first = A.count-1
    var second = B.count-1
    for _ in 0..<B.count {
        A.append(0)
    }
    var index = first+second+1

    while first >= 0 && second >= 0 {
        if B[second] >= A[first] {
            A[index] = B[second]
            second-=1
        } else {
            A[index] = A[first]
            first -= 1
        }
        index -= 1
    }
    while second >= 0 {
         A[index] = B[second]
        second-=1
    }
    return A
}
